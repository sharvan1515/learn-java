import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

import { changePassword } from '../../services/authService';
import { handleApiResponse } from '../../utils/Handlers';

export const changePasswordUser = createAsyncThunk('users/changePassword', async (item, thunkAPI) => {
    try {
        const response = await changePassword(item);
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

const passwordSlice = createSlice({
    name: 'password',
    initialState: {
        loading: false,
        successMessage: '',
        errorMessage: '',
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(changePasswordUser.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(changePasswordUser.fulfilled, (state, action) => {
                state.loading = false;
                state.successMessage = 'Password changed successfully!';
                state.errorMessage = '';
            })
            .addCase(changePasswordUser.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = action.payload;
                state.successMessage = '';
            });
    },
});

export default passwordSlice.reducer;