package com.example.EY.dto.user;
import java.util.List;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EditUserDTO {
    
    @NotBlank(message = "First Name Can not be blank")
    @Size(min = 1, max = 50, message = "First Name must be between 1 and 50 characters")
    private String firstName;

    @NotBlank(message = "lastName Can not be blank")
    @Size(min = 1, max = 50, message = "lastName must be between 1 and 50 characters")
    private String lastName;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should be valid")
    private String email;

    private String dateOfBirth;

    @NotBlank(message = "Gender is mandatory")
    private String gender;

    private String state;

    private String city;

    private String country;

    private String address;

    private String postalCode;

    private String languagePreference;

    private String phoneNumber;

    private String bio;

    private List<Preference> preferences;

}
