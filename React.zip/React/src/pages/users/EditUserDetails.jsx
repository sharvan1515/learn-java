import React from 'react'
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUserItems, loggedInUser, updateBasicInfoUser, updateProfilePicture } from '../../features/users/userSlice';
import { useMemo } from 'react';
import { useState } from 'react';
import { useEffect } from 'react';
import Select from 'react-select';
import { isJsonValid } from '../../utils/Handlers';
import Toast from '../../components/Toast';
import Modal from '../../common/Modal';

function EditUserDetails() {

    const options = useMemo(() => {
        try {
            return JSON.parse(import.meta.env.VITE_PREFERENCE_OPTIONS || '[]');
        } catch (error) {
            return [];
        }
    }, []);

    const dispatch = useDispatch();
    const navigate = useNavigate();

    const { id } = useParams();
    const { users, loading, successMessage, errorMessage } = useSelector((state) => state.users);
    const currentUser = useSelector((state) => state.users?.currentLoginUser);

    const [editMode, setEditMode] = useState(false);
    const [editableUser, setEditableUser] = useState({});
    const [toast, setToast] = useState(null);
    const [isModalOpenForProfilePicture, setIsModalOpenForProfilePicture] = useState(false);
    const [selectedImage, setSelectedImage] = useState(null);
    const [fileImage, setFileImage] = useState(null);
    const [uploadStatus, setUploadStatus] = useState(false);

    const filterUserById = useMemo(() => {
        return users.find((user) => user.id == id);
    }, [id, users]);

    const [selectedOptions, setSelectedOptions] = useState([]);

    const handleSelectChange = (selected) => {
        setSelectedOptions(selected);
    };

    const handlePrint = () => {
        window.print();
    };

    const showToast = (message, type = 'success') => {
        setToast({ message, type });
    };

    const closeToast = () => {
        setToast(null);
    };

    useMemo(() => {
        if (errorMessage) {
            showToast(errorMessage, 'error');
        }
        if (successMessage) {
            showToast(successMessage, 'success');
        }
    }, [errorMessage, successMessage]);

    const handleEditChange = (e) => {
        const { name, value } = e.target;

        setEditableUser((prev) => ({
            ...prev,
            [name]: value
        }));

    };

    const handleSave = async () => {

        const editableUserObject =
        {
            "firstName": editableUser.firstName,
            "lastName": editableUser.lastName,
            "email": editableUser.email,
            "phoneNumber": editableUser.phoneNumber,
            "address": editableUser.address,
            "city": editableUser.city,
            "state": editableUser.state,
            "country": editableUser.country,
            "postalCode": editableUser.postalCode,
            "dateOfBirth": editableUser.dateOfBirth.slice(0, 10),
            "gender": editableUser.gender,
            "bio": editableUser.bio,
            "preferences": selectedOptions,
            "languagePreference": editableUser.languagePreference,
            "id": editableUser.id,
        }


        try {
            await dispatch(updateBasicInfoUser(editableUserObject)).unwrap();
            setEditMode(false);
        } catch (error) {
            //
        }
    };

    const closeModalForProfilePicture = () => {
        setIsModalOpenForProfilePicture(false);
    }

    const openModalForProfilePicture = async () => {
        setIsModalOpenForProfilePicture(true);
    }

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setFileImage(file);
            setSelectedImage(URL.createObjectURL(file));
        }
    };

    const changeProfilePic = () => {
        if (!fileImage) {
            alert('Please select a file to upload!');
            return;
        }
        const file = fileImage;

        setUploadStatus('Uploading...');
        dispatch(updateProfilePicture({ fileData: file, id: id }))
            .then((data) => {
                setUploadStatus(false);
            })
            .catch((error) => {
                console.error('Error updating profile picture:', error);
            });
        setIsModalOpenForProfilePicture(false);
        setSelectedImage(null);
    }

    useEffect(() => {
        setEditableUser(filterUserById);
        if (!filterUserById) {
            navigate("/users");
        }

        if (filterUserById?.preferences) {
            if (!isJsonValid(filterUserById?.preferences)) {
                setSelectedOptions(filterUserById?.preferences);
            } else {
                setSelectedOptions(JSON.parse(filterUserById?.preferences));
            }
        }

        if (currentUser?.user?.id && filterUserById?.id && currentUser.user.id === filterUserById.id) {
            dispatch(loggedInUser());
        }

    }, [filterUserById, navigate]);


    return (
        <div className="p-6 bg-gray-50">
            <div className="flex justify-between items-center p-4">
                <button
                    onClick={() => navigate(-1)}
                    className="px-4 py-2 text-xs bg-gray-300 text-black rounded-md hover:bg-gray-400"
                >
                    <i className="fas fa-arrow-left mr-1"></i>
                    <span>Back</span>
                </button>

                <div className="text-right">
                    <button
                        onClick={handlePrint}
                        className="px-4 py-2 text-xs bg-blue-500 text-white rounded-md hover:bg-blue-600"
                    >
                        <i className="fas fa-print mr-1"></i>
                        <span>Print</span>
                    </button>
                    <button
                        onClick={() => setEditMode(!editMode)}
                        className="px-4 py-2 ml-4 text-xs bg-yellow-500 text-white rounded-md hover:bg-yellow-600"
                    >
                        {editMode ? 'Cancel' : 'Edit'}
                    </button>
                </div>
            </div>
            <div className="border border-gray-300 shadow-md rounded-md bg-white printable">
                <div className="p-4 bg-gray-200 border-b border-gray-300 flex justify-between items-center">
                    <div>
                        <h2 className="text-lg font-semibold text-gray-700">User Details</h2>
                        <p className="text-sm text-gray-500">Full Name: {editableUser?.firstName} {editableUser?.lastName}</p>
                    </div>
                    <div>
                        <img
                            src={editableUser?.profilePictureUrl ?? 'https://placehold.co/600x400'}
                            alt="Profile Picture"
                            className="w-24 h-24 rounded-full object-cover ml-6 pb-1"
                        />
                        <button
                            onClick={openModalForProfilePicture}
                            className=
                            'px-4 py-2 text-xs bg-gray-300 text-black rounded-md hover:bg-gray-400'>
                            {uploadStatus ? <>{uploadStatus}</> : 'Change Profile Picture'}

                        </button>
                    </div>
                </div>

                <table className="w-full border-collapse">
                    <tbody>
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">First Name</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="text"
                                        name="firstName"
                                        value={editableUser?.firstName}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.firstName
                                )}
                            </td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Last Name</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="text"
                                        name="lastName"
                                        value={editableUser?.lastName}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.lastName
                                )}
                            </td>
                        </tr>
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Email</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="email"
                                        name="email"
                                        value={editableUser.email}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.email || 'Not Available'
                                )}
                            </td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Phone Number</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="text"
                                        name="phoneNumber"
                                        value={editableUser?.phoneNumber || ''}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.phoneNumber || 'Not Available'
                                )}
                            </td>
                        </tr>

                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Address</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <textarea name="address"
                                        value={editableUser?.address || ''}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"></textarea>

                                ) : (
                                    editableUser?.address || 'Not Available'
                                )}
                            </td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">City</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="text"
                                        name="city"
                                        value={editableUser?.city || ''}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.city || 'Not Available'
                                )}
                            </td>
                        </tr>
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">State</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="text"
                                        name="state"
                                        value={editableUser?.state || ''}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.state || 'Not Available'
                                )}
                            </td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Country</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="text"
                                        name="country"
                                        value={editableUser?.country || ''}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.country || 'Not Available'
                                )}
                            </td>
                        </tr>
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Postal Code</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="number"
                                        name="postalCode"
                                        value={editableUser?.postalCode || ''}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.postalCode || 'Not Available'
                                )}
                            </td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Date of Birth</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="date"
                                        name="dateOfBirth"
                                        value={editableUser?.dateOfBirth?.slice(0, 10) || ''}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.dateOfBirth ? editableUser.dateOfBirth.slice(0, 10) : 'Not Available'
                                )}
                            </td>
                        </tr>

                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">gender</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <div className="w-full p-2">
                                        <label className="mr-4">
                                            <input
                                                type="radio"
                                                name="gender"
                                                value="MALE"
                                                checked={editableUser?.gender === 'MALE'}
                                                onChange={handleEditChange}
                                                className="mr-2"
                                            />
                                            Male
                                        </label>

                                        <label className="mr-4">
                                            <input
                                                type="radio"
                                                name="gender"
                                                value="FEMALE"
                                                checked={editableUser?.gender === 'FEMALE'}
                                                onChange={handleEditChange}
                                                className="mr-2"
                                            />
                                            Female
                                        </label>

                                        <label>
                                            <input
                                                type="radio"
                                                name="gender"
                                                value="OTHER"
                                                checked={editableUser?.gender === 'OTHER'}
                                                onChange={handleEditChange}
                                                className="mr-2"
                                            />
                                            Other
                                        </label>
                                    </div>

                                ) : (
                                    editableUser?.gender || 'Not Available'
                                )}
                            </td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Bio</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <textarea name="bio"
                                        value={editableUser?.bio || ''}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"></textarea>
                                ) : (
                                    editableUser?.bio || 'Not Available'
                                )}
                            </td>
                        </tr>
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">preferences</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (

                                    <Select
                                        name='preferences'
                                        id="preferences"
                                        options={options}
                                        isMulti
                                        value={selectedOptions} // Bind selected options to state
                                        onChange={handleSelectChange} // Handle selection changes
                                        className="mt-2"
                                    />
                                ) : (
                                    selectedOptions && selectedOptions.length > 0 ? (
                                        selectedOptions.map(option => (
                                            <span key={option.value} className="inline-block bg-blue-500 text-white text-xs font-semibold py-1 px-2 rounded-full mr-2">{option.label}</span>
                                        ))
                                    ) : (
                                        'Not Available'
                                    ))}
                            </td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Language Preference</th>
                            <td className="p-3 text-sm text-gray-800">
                                {editMode ? (
                                    <input
                                        type="text"
                                        name="languagePreference"
                                        value={editableUser?.languagePreference || ''}
                                        onChange={handleEditChange}
                                        className="w-full p-2 border border-gray-300 rounded-md"
                                    />
                                ) : (
                                    editableUser?.languagePreference || 'Not Available'
                                )}
                            </td>
                        </tr>
                    </tbody>
                </table>

                {editMode && (
                    <div className="p-4 text-right">
                        <button
                            disabled={loading}
                            onClick={handleSave}
                            className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600"
                        >
                            {
                                loading ? 'Updating...' : 'Update'
                            }
                        </button>
                    </div>
                )}
            </div>

            {
                isModalOpenForProfilePicture && (
                    <Modal>
                        <p>Profile Picture Change</p>
                        <div className="mt-4">
                            <input
                                type="file"
                                accept="image/*"
                                onChange={handleImageChange}
                                className="block mb-4"
                                aria-label="Select Profile Picture"
                            />

                            {/* Image preview */}
                            {selectedImage && (
                                <div className="mb-4">
                                    <img
                                        src={selectedImage}
                                        alt="Profile Preview"
                                        className="w-32 h-32 object-cover rounded-full"
                                    />
                                </div>
                            )}
                        </div>
                        <div className="mt-4 flex justify-end space-x-4">
                            <button
                                onClick={closeModalForProfilePicture}
                                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={changeProfilePic}
                                className="px-4 py-2 bg-blue-500 text-white rounded-md"
                            >
                                Confirm
                            </button>
                        </div>
                    </Modal>
                )
            }
            {toast &&
                (
                    <Toast
                        message={toast.message}
                        type={toast.type}
                        onClose={closeToast}
                    />
                )}

        </div>
    );
}

export default EditUserDetails