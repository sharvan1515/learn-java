package com.example.EY.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @GetMapping("/hello")
    public String hello() {
        return "Hello Kumar";
    }

    @GetMapping("/")
    public String helloPage() {
        return "Hello Sharvan Kumar";
    }

    @GetMapping("/admin")
    public String adminPage() {
        return "Hello Admin";
    }

    @GetMapping("/user")
    public String userPage() {
        return "Hello User";
    }

}
