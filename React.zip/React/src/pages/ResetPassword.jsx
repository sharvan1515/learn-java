// ResetPassword.js
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

import { doResetPassword } from "../features/auth/authSlice";
import { useDispatch, useSelector } from 'react-redux';

const ResetPassword = () => {

    const { loading, successMessage, errorMessage } = useSelector((state) => state.auth);

    const navigate = useNavigate();
    const dispatch = useDispatch();
    const location = useLocation();

    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [email, setEmail] = useState('');
    const [token, setToken] = useState('');
    const [formError, setFormError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (newPassword !== confirmPassword) {
            setFormError('Passwords do not match!');
            return;
        }

        if (newPassword.length < 8 || confirmPassword.length < 8) {
            setFormError('The password field must be at least 8 characters.');
            return;
        }

        setFormError('');

        try {
            await dispatch(doResetPassword(
                {
                    token: token,
                    password: newPassword,
                    password_confirmation: confirmPassword,
                    email: email,
                }
            )).unwrap();

            setTimeout(() => {
                navigate('/login');
                window.location.reload();
            }, 3000)

            resetForm();
        } catch (error) {
            resetForm();
        }

    };


    useEffect(() => {
        const token = localStorage.getItem('accessToken');
        if (token) {
            navigate('/dashboard');
        }

        const queryParams = new URLSearchParams(location.search);
        setToken(queryParams.get('token'));
        setEmail(queryParams.get('email'));

    }, [location, navigate]);

    return (
        <div className="flex justify-center items-center h-screen bg-gray-200">
            <div className="bg-white p-8 rounded-lg shadow-md w-96">
                <h2 className="text-2xl font-semibold text-center mb-6">Reset Password</h2>

                {errorMessage && <p className="text-red-500 text-center mb-4">{errorMessage}</p>}
                {successMessage && <p className="text-green-500 text-center mb-4">{successMessage}</p>}
                {formError && <p className="text-red-500 text-center mb-4">{formError}</p>}

                <form onSubmit={handleSubmit}>
                    {/* New Password Field */}
                    <div className="mb-4">
                        <label htmlFor="newPassword" className="block text-gray-700">New Password</label>
                        <input
                            type="password"
                            id="newPassword"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg mt-2"
                            required
                        />
                    </div>

                    {/* Confirm Password Field */}
                    <div className="mb-6">
                        <label htmlFor="confirmPassword" className="block text-gray-700">Confirm Password</label>
                        <input
                            type="password"
                            id="confirmPassword"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg mt-2"
                            required
                        />
                    </div>

                    {/* Submit Button */}
                    <button
                        type="submit"
                        className={`w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 ${loading ? 'cursor-not-allowed opacity-50' : ''}`}
                        disabled={loading}
                    >
                        {loading ? 'Resetting...' : 'Reset Password'}
                    </button>
                </form>

                <div className="mt-4 text-center">
                    <p>
                        <a href="/login" className="text-blue-600 hover:underline">
                            Login
                        </a>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default ResetPassword;
