package com.example.EY.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.EY.dto.auth.RegisterDTO;
import com.example.EY.dto.user.AddUserFromBackendDTO;
import com.example.EY.dto.user.UserProfileDTO;
import com.example.EY.model.Role;
import com.example.EY.model.User;
import com.example.EY.repository.RoleRepository;
import com.example.EY.repository.UserRepository;

import jakarta.transaction.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.management.relation.RelationNotFoundException;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Optional<User> user = userRepository.findByEmail(username);

        return user.map(UserInfoDetails::new)
                .orElseThrow(() -> new UsernameNotFoundException("User not found " + username));
    }

    @Transactional
    public ResponseEntity<?> saveUser(RegisterDTO registerDTO) throws RelationNotFoundException {
        Map<String, Object> response = new HashMap<>();
        try {
            Set<Role> roles = new HashSet<>();

            if (registerDTO.getRoles() == null) {
                Role role = roleRepository.findByRoleName("USER");
                if (role == null) {
                    throw new RelationNotFoundException("Role with name USER not found");
                }
                roles.add(role);
            } else {
                for (String roleName : registerDTO.getRoles()) {
                    Role role = roleRepository.findByRoleName(roleName);
                    if (role == null) {
                        throw new RelationNotFoundException("Role with name " + roleName + " not found");
                    }
                    roles.add(role);
                }
            }
            Optional<User> existingUser = userRepository.findByEmail(registerDTO.getEmail());
            if (existingUser.isPresent()) {
                response.put("email", "Email must be unique");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            User user = new User();
            user.setFirstName(registerDTO.getFirstName());
            user.setLastName(registerDTO.getLastName());
            user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
            user.setEmail(registerDTO.getEmail());
            user.setRoles(roles);
            userRepository.save(user);
            response.put("message", "User Created");
            response.put("user", registerDTO);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> saveUserByBackend(AddUserFromBackendDTO addUserFromBackendDTO) {
        Map<String, Object> response = new HashMap<>();
        try {
            Set<Role> roles = new HashSet<>();
            if (addUserFromBackendDTO.getRoles() == null) {
                Role role = roleRepository.findByRoleName("USER");
                if (role == null) {
                    throw new RelationNotFoundException("Role with name USER not found");
                }
                roles.add(role);
            } else {
                for (String roleName : addUserFromBackendDTO.getRoles()) {
                    Role role = roleRepository.findByRoleName(roleName);
                    if (role == null) {
                        throw new RelationNotFoundException("Role with name " + roleName + " not found");
                    }
                    roles.add(role);
                }
            }
            Optional<User> existingUser = userRepository.findByEmail(addUserFromBackendDTO.getEmail());
            if (existingUser.isPresent()) {
                response.put("email", "Email must be unique");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }
            User user = new User();
            user.setFirstName(addUserFromBackendDTO.getFirstName());
            user.setLastName(addUserFromBackendDTO.getLastName());
            user.setPassword(passwordEncoder.encode("12345678"));
            user.setEmail(addUserFromBackendDTO.getEmail());
            user.setRoles(roles);
            userRepository.save(user);
            response.put("message", "User Created");
            response.put("user", addUserFromBackendDTO);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }   

    public String processForgotPassword(String email) {
        Optional<User> user = userRepository.findByEmail(email);
        if (user.isPresent()) {
            User foundUser = user.get();
            String token = UUID.randomUUID().toString();
            foundUser.setResetToken(token);
            foundUser.setTokenExpiryDate(LocalDateTime.now().plusHours(1));
            userRepository.save(foundUser);
            return emailService.sendResetTokenEmail(foundUser.getEmail(), token);
        }
        return "null";
    }

    public Boolean validateResetToken(String token) {
        Optional<User> user = userRepository.findByResetToken(token);
        if (user.isPresent()) {
            User foundUser = user.get();
            if (foundUser.getTokenExpiryDate().isBefore(LocalDateTime.now())) {
                return false;
            }
            return true;
        }
        return false;
    }

    public boolean updatePassword(String token, String newPassword) {
        Optional<User> user = userRepository.findByResetToken(token);
        if (user.isPresent()) {
            User foundUser = user.get();
            foundUser.setPassword(passwordEncoder.encode(newPassword));
            foundUser.setResetToken(null);
            foundUser.setTokenExpiryDate(null);
            userRepository.save(foundUser);
            return true;
        }
        return false;
    }

    public ResponseEntity<Map<String, String>> changePassword(String username, String oldPassword, String newPassword) {
        Map<String, String> response = new HashMap<>();
        try {
            Optional<User> userOptional = userRepository.findByEmail(username);

            if (!userOptional.isPresent()) {
                response.put("message", "User Not Found");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            User user = userOptional.get();
            if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
                response.put("message", "Current Password is Incorrect");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            if (newPassword.length() <= 3) {
                response.put("message", "Password must be at least 4 characters long.");
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);
            response.put("message", "Password Changed!");
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            response.put("message", "An error occurred while changing the password.");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> getTheUserDetailsByUsername(String username) {

        try {
            Optional<User> userOptional = userRepository.findByEmail(username);
            return userOptional.map(user -> {
                Set<String> roleNames = user.getRoles().stream()
                        .map(role -> role.getRoleName())
                        .collect(Collectors.toSet());

                Set<Long> roleId = user.getRoles().stream().map(role -> role.getId()).collect(Collectors.toSet());

                UserProfileDTO userProfileDTO = new UserProfileDTO(
                        user.getId(),
                        user.getFirstName(),
                        user.getLastName(),
                        user.getEmail(),
                        user.getPhoneNumber(),
                        user.getAddress(),
                        user.getCity(),
                        user.getState(),
                        user.getCountry(),
                        user.getPostalCode(),
                        user.getDateOfBirth(),
                        user.getGender() == null ? "" : user.getGender().name(),
                        user.getProfilePictureUrl(),
                        user.getBio(),
                        user.getLanguagePreference(),
                        user.getStatus().name(),
                        user.getLastLogin(),
                        user.getLoginAttempts(),
                        user.getTokenExpiryDate(),
                        user.isEmailVerified(),
                        user.isPhoneVerified(),
                        user.isTwoFactorEnabled(),
                        user.getPreferences(),
                        user.getSubscriptionType().name(),
                        user.getSubscriptionExpiry(),
                        user.getReferralCode(),
                        user.getLastPasswordChange(),
                        user.isEmailNotifications(),
                        user.isPhoneNotifications(),
                        user.isTermsAccepted(),
                        user.getCreatedAt(),
                        user.getUpdatedAt(),
                        roleId,
                        roleNames
                        );
                return new ResponseEntity<>(userProfileDTO, HttpStatus.OK);
            }).orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));
        } catch (UsernameNotFoundException e) {
            return new ResponseEntity<>("User not found with username: " + username, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred while processing the request.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}