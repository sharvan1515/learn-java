import React, { useState, useEffect, useMemo } from 'react';
import Modal from '../../common/Modal';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUserItems, createUserItem, updateRole, updateUserStatusType, deleteUserData } from '../../features/users/userSlice';
import { fetchRoleItems } from '../../features/roles/roleSlice';
import { Button } from '../../components/Button';
import { Pagination } from '../../common/Pagination';
import { useNavigate } from 'react-router-dom';
import { validateField } from '../../utils/Handlers';
import { doForgotPassword } from '../../features/auth/authSlice';
import { userStatusList } from '../../utils/Handlers';
import DialogModal from '../../common/DialogModal';
import { updatePageAfterDelete } from '../../utils/updatePageAfterDelete';
import Toast from '../../components/Toast';
import BasicSearch from '../../common/BasicSearch';
import FilterTab from './FilterTab';

function Users() {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const { users, loading, successMessage, errorMessage } = useSelector((state) => state.users);
    const currentUserId = useSelector((state) => state.users.currentLoginUser?.id);
    const roles = useSelector((state) => state.roles.roles);

    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [rolesSelected, setRolesSelected] = useState('');
    const [userStatus, setUserStatus] = useState('');
    const [toast, setToast] = useState(null);

    const [firstNameError, setFirstNameError] = useState('');
    const [lastNameError, setLastNameError] = useState('');
    const [emailError, setEmailError] = useState('');
    const [rolesSelectedError, setRolesSelectedError] = useState('');
    const [userStatusError, setUserStatusError] = useState('');

    const [showModal, setShowModal] = useState(false);
    const [showModalDialog, setShowModalDialog] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [currentUser, setCurrentUser] = useState(null);
    const [changeType, setChangeType] = useState(null);
    const [restLinkLoading, setRestLinkLoading] = useState({});

    const usersPerPage = 2;
    const indexOfLastUser = currentPage * usersPerPage;
    const indexOfFirstUser = indexOfLastUser - usersPerPage;
    // const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);
    const [searchQuery, setSearchQuery] = useState('');
    const [startDate, setStartDate] = useState('');

    useEffect(() => {
        dispatch(fetchUserItems());
        dispatch(fetchRoleItems());
    }, []);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    const handleModalOpen = (user = null, type = null) => {
        resetForm();
        setShowModal(true);
        setCurrentUser(user);
        setChangeType(type);
        setRolesSelected(user?.roleId[0] || '');
        setUserStatus(user?.status || '');
    };

    

    const handleModalClose = () => {
        setShowModal(false);
        setCurrentUser(null);
        setChangeType(null);
        resetForm();
    };

    const handleSave = async () => {
        validateField(firstName, setFirstNameError, 'First name cannot be blank');
        validateField(lastName, setLastNameError, 'Last name cannot be blank');
        validateField(email, setEmailError, 'Email cannot be blank', 'email');
        validateField(rolesSelected, setRolesSelectedError, 'You have not selected role');
        if (firstName === '' || lastName === '' || email === '' || rolesSelected === '') {
            return;
        }
        const registerData = {
            firstName: firstName,
            lastName: lastName,
            email: email,
            roles: [rolesSelected],
        };
        try {
            await dispatch(createUserItem(registerData)).unwrap();
            dispatch(fetchUserItems());
            handleModalClose();
        } catch (error) {
            console.log(error);
        }
    };

    const handleResetLink = async (user) => {
        setRestLinkLoading(prev => ({ ...prev, [user.id]: true }));
        try {
            await dispatch(doForgotPassword({ email: user.email })).unwrap();
            setRestLinkLoading(prev => ({ ...prev, [user.id]: false }));
            alert('Reset Link Has been sent');
        } catch (error) {
            setRestLinkLoading(prev => ({ ...prev, [user.id]: false }));
            alert('Error occurred');
        }
    };

    const handleUpdateRole = async () => {
        validateField(rolesSelected, setRolesSelectedError, 'You have not selected role');
        if (rolesSelected === '') return;
        try {
            await dispatch(updateRole({ id: currentUser.id, role: rolesSelected })).unwrap();
            dispatch(fetchUserItems());
            handleModalClose();
        } catch (error) {
            console.log(error);
        }
    };

    const handleUpdateStatus = async () => {
        validateField(userStatus, setUserStatusError, 'You have not selected status');

        if (userStatus === '') return;

        try {
            await dispatch(updateUserStatusType({ id: currentUser.id, status: userStatus })).unwrap();
            handleModalClose();
        } catch (error) {
            console.log(error);
        }
    };

    const handleDeleteModalOpen = (user) => {
        setShowModalDialog(true);
        setCurrentUser(user);
    }

    const handleDeleteModalClose = () => {
        setShowModalDialog(false);
        setCurrentUser(null);
    }

    const handleDeleteUser = async () => {

        if (currentUser) {
            try {
                await dispatch(deleteUserData(currentUser.id)).unwrap();
                const updatedPage = updatePageAfterDelete(users, currentPage, usersPerPage, currentUser?.id)
                setCurrentPage(updatedPage);
            } catch (error) {
                console.log(error)
            }
            setShowModalDialog(false);
        }
    }


    const routeToNewPage = (user, routeName) => {
        navigate(`/${routeName}/${user.id}`, { state: { user } });
    };

    const resetForm = () => {
        setFirstName('');
        setLastName('');
        setEmail('');
        setRolesSelected('');
        setFirstNameError('');
        setLastNameError('');
        setEmailError('');
        setRolesSelectedError('');
        setUserStatusError('');
        setUserStatus('');
    };

    const showToast = (message, type = 'success') => {
        setToast({ message, type });
    };

    const closeToast = () => {
        setToast(null);
    };

    const filteredUsers = useMemo(() => {
        return users.filter((user) =>
            (user.first_name && user.first_name.toLowerCase().includes(searchQuery.toLowerCase())) ||
            (user.email && user.email.toLowerCase().includes(searchQuery.toLowerCase())) ||
            (user.last_name && user.last_name.toLowerCase().includes(searchQuery.toLowerCase()))
        );
    }, [users, searchQuery]);

    const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);

    useMemo(() => {
        if (errorMessage) {
            showToast(errorMessage, 'error');
        }
        if (successMessage) {
            showToast(successMessage, 'success');
        }

    }, [errorMessage, successMessage]);

    const totalPages = Math.ceil(users.length / usersPerPage);

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h1 className="text-xl font-bold mb-6">Users</h1>
            {/* <FilterTab /> */}

            <Button
                onClick={() => handleModalOpen()}
                className="mt-4 mb-2 p-1 text-sm bg-blue-500 text-white rounded-lg flex items-center hover:bg-blue-600 focus:outline-none"
            >
                <i className="fas fa-user-plus mr-2"></i> Add New User
            </Button>
            <BasicSearch onSearch={setSearchQuery} />

            <table className="min-w-full table-auto border-collapse border border-gray-300 text-sm">
                <thead>
                    <tr className="bg-gray-200">
                        <th className="px-4 py-2 border">First Name</th>
                        <th className="px-4 py-2 border">Last Name</th>
                        <th className="px-4 py-2 border">Full Name</th>
                        <th className="px-4 py-2 border">Email</th>
                        <th className="px-4 py-2 border">Role</th>
                        <th className="px-4 py-2 border">Status</th>
                        <th className="px-4 py-2 border text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        currentUsers.length === 0 ? (
                            <tr>
                                <td colSpan="7" className="text-center">
                                    {loading && <p>Loading...</p>}
                                </td>
                            </tr>
                        ) : (
                            currentUsers.map((user) => (
                                <tr key={user.id} className="border-b">
                                    <td className="px-4 py-2">{user.firstName}</td>
                                    <td className="px-4 py-2">{user.lastName}</td>
                                    <td className="px-4 py-2">{user.firstName} {user.lastName}</td>
                                    <td className="px-4 py-2">{user.email}</td>
                                    <td className="px-4 py-2">
                                        {user.roles && user.roles.length > 0
                                            ? user.roles.map((role, index) => (
                                                <span
                                                    key={`${index}-${role}`}
                                                    className="inline-block bg-blue-500 text-white text-xs font-semibold py-1 px-2 rounded-full mr-2"
                                                >
                                                    {role}
                                                </span>
                                            ))
                                            : 'No roles assigned'}
                                    </td>
                                    <td className="px-4 py-2">
                                        {user.status === 'ACTIVE' && <span className="bg-green-400 text-white p-2">Active</span>}
                                        {user.status === 'INACTIVE' && <span className="bg-yellow-400 text-white p-2">Inactive</span>}
                                        {user.status === 'SUSPENDED' && <span className="bg-red-400 text-white p-2">Suspended</span>}
                                    </td>
                                    <td className="px-4 py-2 text-center">
                                        <i
                                            className={`fas fa-user-tag cursor-pointer mr-2 ${currentUserId === user.id ? 'disabled' : ''}`}
                                            title="Change Role"
                                            onClick={currentUserId === user.id ? null : () => handleModalOpen(user, 'role')}
                                        />
                                        <i
                                            className={`fas fa-exchange-alt cursor-pointer mr-2 ${currentUserId === user.id ? 'disabled' : ''}`}
                                            title="Change Status"
                                            onClick={() => handleModalOpen(user, 'status')}
                                        />
                                        <i
                                            className="fas fa-edit cursor-pointer mr-2"
                                            title="Edit Details"
                                            onClick={() => routeToNewPage(user, 'editUserDetails')}
                                        />
                                        <i
                                            className="fas fa-eye cursor-pointer mr-2"
                                            title="View Details"
                                            onClick={() => routeToNewPage(user, 'showUserDetails')}
                                        />
                                        {restLinkLoading[user.id] ? (
                                            <i className="fas fa-spinner fa-spin text-blue-500 mr-2"></i>
                                        ) : (
                                            <i
                                                className="fas fa-envelope  cursor-pointer mr-2"
                                                title="Send Reset Password link"
                                                onClick={() => handleResetLink(user)}
                                            />
                                        )}

                                        <i
                                            className={`fas fa-trash text-red-500 cursor-pointer mr-2 ${currentUserId === user.id ? 'disabled' : ''}`}
                                            title="Delete User"
                                            onClick={currentUserId === user.id ? null : () => handleDeleteModalOpen(user)}
                                        />
                                    </td>
                                </tr>
                            ))
                        )
                    }
                </tbody>
            </table>

            <Pagination totalPages={totalPages} currentPage={currentPage} paginate={paginate} />

            {showModal && (
                <Modal>
                    <h2 className="text-xl font-bold mb-4">
                        {currentUser && changeType === 'role'
                            ? 'Change Role'
                            : changeType === 'status'
                                ? 'Change Status'
                                : 'Add New User'}
                    </h2>

                    {currentUser && changeType === 'role' && (
                        <>
                            <select
                                value={rolesSelected}
                                onChange={(e) => setRolesSelected(e.target.value)}
                                className="border border-gray-300 p-2 mb-4 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-700 shadow-sm"
                            >
                                <option value="" disabled>Select a role</option>
                                {roles.map((roleOption) => (
                                    <option key={roleOption.roleName} value={roleOption.id}>
                                        {roleOption.roleName.charAt(0).toUpperCase() + roleOption.roleName.slice(1)}
                                    </option>
                                ))}
                            </select>
                            {rolesSelectedError && <span className="text-red-500">{rolesSelectedError}</span>}
                            <div className="flex justify-between">
                                <button onClick={handleModalClose} className="px-4 py-2 bg-gray-400 text-white rounded-md">
                                    Cancel
                                </button>
                                <button
                                    onClick={handleUpdateRole}
                                    className="px-4 py-2 bg-blue-500 text-white rounded-md"
                                    disabled={loading}
                                >
                                    {loading ? 'Updating...' : 'Update'}
                                </button>
                            </div>
                        </>
                    )}

                    {currentUser && changeType === 'status' && (
                        <>
                            <select
                                value={userStatus}
                                onChange={(e) => setUserStatus(e.target.value)}
                                className="border border-gray-300 p-2 mb-4 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-700 shadow-sm"
                            >
                                <option value="" disabled>Select a status</option>
                                {userStatusList.map((statusOption) => (
                                    <option key={statusOption.statusType} value={statusOption.statusType}>
                                        {statusOption.statusType}
                                    </option>
                                ))}
                            </select>
                            {userStatusError && <span className="text-red-500">{userStatusError}</span>}
                            <div className="flex justify-between">
                                <button onClick={handleModalClose} className="px-4 py-2 bg-gray-400 text-white rounded-md">
                                    Cancel
                                </button>
                                <button
                                    onClick={handleUpdateStatus}
                                    className="px-4 py-2 bg-blue-500 text-white rounded-md"
                                    disabled={loading}
                                >
                                    {loading ? 'Updating...' : 'Update'}
                                </button>
                            </div>
                        </>
                    )}

                    {!currentUser && (
                        <>
                            <input
                                type="text"
                                value={firstName}
                                onChange={(e) => setFirstName(e.target.value)}
                                placeholder="First Name"
                                className="border p-2 mb-4 w-full"
                            />
                            {firstNameError && <span className="text-red-500">{firstNameError}</span>}
                            <input
                                type="text"
                                value={lastName}
                                onChange={(e) => setLastName(e.target.value)}
                                placeholder="Last Name"
                                className="border p-2 mb-4 w-full"
                            />
                            {lastNameError && <span className="text-red-500">{lastNameError}</span>}
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="Email"
                                className="border p-2 mb-4 w-full"
                            />
                            {emailError && <span className="text-red-500">{emailError}</span>}
                            <select
                                value={rolesSelected}
                                onChange={(e) => setRolesSelected(e.target.value)}
                                className="border border-gray-300 p-2 mb-4 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-gray-700 shadow-sm"
                            >
                                <option value="" disabled>Select a role</option>
                                {roles.map((roleOption) => (
                                    <option key={roleOption.id} value={roleOption.roleName}>
                                        {roleOption.roleName.charAt(0).toUpperCase() + roleOption.roleName.slice(1)}
                                    </option>
                                ))}
                            </select>
                            {rolesSelectedError && <span className="text-red-500">{rolesSelectedError}</span>}
                            <div className="flex justify-between">
                                <button onClick={handleModalClose} className="px-4 py-2 bg-gray-400 text-white rounded-md">
                                    Cancel
                                </button>
                                <button
                                    onClick={handleSave}
                                    className="px-4 py-2 bg-blue-500 text-white rounded-md"
                                    disabled={loading}
                                >
                                    {loading ? 'Saving...' : 'Save'}
                                </button>
                            </div>
                        </>
                    )}
                </Modal>
            )}

            {showModalDialog && (
                <DialogModal title="Delete Role">
                    <p>Are you sure you want to delete this user?</p>
                    <div className="mt-4 flex justify-end space-x-4">
                        <button
                            onClick={handleDeleteModalClose}
                            className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleDeleteUser}
                            className="px-4 py-2 bg-blue-500 text-white rounded-md"
                        >
                            Confirm
                        </button>
                    </div>
                </DialogModal>
            )}

            {toast &&
                <Toast
                    message={toast.message}
                    type={toast.type}
                    onClose={closeToast}
                />
            }

        </div>
    );
}

export default Users;
