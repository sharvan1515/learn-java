import React from 'react';

const DialogModal = ({ title, children }) => {
    
    return (
        <div className="fixed inset-0 flex justify-center items-center bg-gray-600 bg-opacity-50 z-50">
            <div className="bg-white p-6 rounded-lg shadow-lg max-w-lg w-full">
                <h2 className="text-xl font-semibold mb-4">{title}</h2>
                <div>{children}</div>
            </div>
        </div>
    );
};

export default DialogModal;
