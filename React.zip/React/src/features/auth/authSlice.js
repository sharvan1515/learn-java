import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

import { login, forgotPassword, resetPassword  } from '../../services/authService';
import { handleApiResponse } from '../../utils/Handlers';

export const doLogin = createAsyncThunk('auth/login', async (item, thunkAPI) => {

    try {
        const response = await login(item);
        return response;
    } catch (error) {

        return handleApiResponse(error, thunkAPI);
    }
});

export const doForgotPassword = createAsyncThunk('auth/forgotPassword', async (item, thunkAPI) => {
    try {
        const response = await forgotPassword(item);
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const doResetPassword = createAsyncThunk('auth/resetPassword', async (item, thunkAPI) => {
    try {
        const response = await resetPassword(item);
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

const authSlice = createSlice({
    name: 'auth',
    initialState: {
        loading: false,
        successMessage: '',
        errorMessage: '',
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(doLogin.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(doLogin.fulfilled, (state, action) => {
                state.loading = false;
                state.successMessage = 'Logged In! Redirecting to home page within 3 seconds'
                state.errorMessage = '';
            })
            .addCase(doLogin.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = action.payload;
                state.successMessage = '';
            })


            .addCase(doForgotPassword.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(doForgotPassword.fulfilled, (state, action) => {
                state.loading = false;
                state.successMessage = 'Password reset link sent to your email!'
                state.errorMessage = '';
            })
            .addCase(doForgotPassword.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = 'Reset Link has not been sent.';
                state.successMessage = action.payload;
            })

            .addCase(doResetPassword.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(doResetPassword.fulfilled, (state, action) => {
                state.loading = false;
                state.successMessage = 'Your password has been successfully reset!'
                state.errorMessage = '';
            })
            .addCase(doResetPassword.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = 'Something went wrong, please try again.';
                state.successMessage = action.payload;
            });
    },
});

export default authSlice.reducer;