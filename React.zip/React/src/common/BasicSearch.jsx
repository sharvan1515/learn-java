import React, { useState } from 'react'

function BasicSearch({ onSearch, placeholder }) {

    const [query, setQuery] = useState('');
    
    const handleSearchChange = (e) => {
        const value = e.target.value;
        setQuery(value);
        onSearch(value);  // Pass the search query up to the parent
    };


    return (
        <div className="mb-4 flex justify-end">
            <input
                type="text"
                value={query}
                onChange={handleSearchChange}
                placeholder={placeholder ? placeholder : "Search..."}
                className="border p-2 w-1/3"
            />
        </div>
    )
}

export default BasicSearch