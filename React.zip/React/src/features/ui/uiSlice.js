// src/slices/uiSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    currentPage: 1,
    totalPages: 1,
    showModal: false,
    loading: false,
    loadingText: '',
    sidebarCollapsed: false,
    sidebarToggled: false,
    sidebarHovered: false,
};

const uiSlice = createSlice({
    name: 'ui',
    initialState,
    reducers: {
        setCurrentPage(state, action) {
            state.currentPage = action.payload;
        },
        setTotalPages(state, action) {
            state.totalPages = action.payload;
        },
        setShowModal(state, action) {
            state.showModal = action.payload;
        },
        setLoading(state, action) {
            state.loading = action.payload;
        },
        setLoadingText(state, action) {
            state.loadingText = action.payload;
        },
        setSidebarCollapsed(state, action) {
            state.sidebarCollapsed = action.payload;
        },
        setSidebarToggled(state, action) {
            state.sidebarToggled = action.payload;
        },
        setSidebarHovered(state, action) {
            state.sidebarHovered = action.payload;
        },
    },
});

export const { setCurrentPage, setTotalPages, setShowModal, setLoading, setLoadingText, setSidebarCollapsed, setSidebarToggled, setSidebarHovered } = uiSlice.actions;
export default uiSlice.reducer;
