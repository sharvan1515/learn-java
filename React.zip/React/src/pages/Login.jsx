import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { doLogin } from "../features/auth/authSlice";
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

const Login = () => {
    const { loading, successMessage, errorMessage } = useSelector((state) => state.auth);

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [userType, setUserType] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setIsLoading(true);
        try {
            const response = await dispatch(doLogin({
                email: username,
                password: password,
                roles: userType,
            })).unwrap();

            if (response && response.accessToken && response.refreshToken) {
                // if (response.roles && response.roles.some(role => ['ADMIN', 'MANAGER', 'SCHOOL'].includes(role))) {
                //     localStorage.setItem('authToken', response.token);
                //     localStorage.setItem('role', response.roles);
                // } else {
                //     setError('You do not have permission to access this application.');
                // }

                localStorage.setItem('accessToken', response.accessToken);
                localStorage.setItem('refreshToken', response.refreshToken);
            } else {
                setError('Invalid username or password');
            }

            setTimeout(() => {
                navigate('/');
            }, 3000);

            setError('');
            resetForm();
        } catch (error) {
            setError('Invalid username or password');
            setIsLoading(false);
            resetForm();
        }
    };

    const resetForm = () => {
        setUsername('');
        setPassword('');
    };

    useEffect(() => {
        const token = localStorage.getItem('accessToken');
        if (token) {
            navigate('/');
        }


    }, [navigate]);

    return (
        <div className="flex justify-center items-center h-screen bg-gray-200">
            <div className="bg-white p-8 rounded-lg shadow-md w-96">
                <h2 className="text-2xl font-semibold text-center mb-6">Login</h2>

                {/* Display error message */}

                {errorMessage && (
                    typeof errorMessage === 'object' ? (
                        Object.entries(errorMessage).map(([field, messages]) => (
                            <div key={field} className="text-red-500 text-center mb-4">
                                <div key={field} className="text-center mb-4">
                                    <p key={field}>{messages}</p>
                                </div>
                            </div>
                        ))
                    ) : (
                        <p className="text-red-500 text-center mb-4">{errorMessage}</p>
                    )
                )}

                {successMessage && <p className="text-green-500 text-center mb-4">{successMessage}</p>}

                <form onSubmit={handleSubmit}>
                    {/* UserType dropdown */}
                    <div className="mb-4">
                        <label htmlFor="userType" className="block text-sm font-medium text-gray-700">Select User Type</label>
                        <select
                            value={userType}
                            onChange={(e) => setUserType(e.target.value)}
                            id="userType"
                            name="userType"
                            className="mt-2 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"

                        >
                            <option value="" disabled>Select User Type</option>
                            <option value="ADMIN">Admin</option>
                            <option value="MANAGER">Manager</option>
                            <option value="SCHOOL">School</option>
                        </select>
                    </div>

                    {/* Username field */}
                    <div className="mb-4">
                        <label htmlFor="username" className="block text-gray-700">Username</label>
                        <input
                            type="text"
                            id="username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg mt-2"

                        />
                    </div>

                    {/* Password field */}
                    <div className="mb-6">
                        <label htmlFor="password" className="block text-gray-700">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg mt-2"

                        />
                    </div>

                    {/* Submit button */}
                    <button
                        type="submit"
                        className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                        disabled={isLoading}
                    >
                        {isLoading ? 'Logging in...' : 'Login'}
                    </button>
                </form>

                {/* Forgot Password Link */}
                <div className="mt-4 text-center">
                    <Link
                        to="/forgot-password"
                        className="text-blue-600 hover:text-blue-700"
                    >
                        Forgot Password?
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default Login;
