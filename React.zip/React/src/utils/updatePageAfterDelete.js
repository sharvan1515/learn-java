export const updatePageAfterDelete = (filteredData, currentPage, perPageItems, currentId, identifier='id') => {
    
    const newFilteredData = filteredData.filter(data => data[identifier] !== currentId);

    const totalPages = Math.ceil(newFilteredData.length / perPageItems);
    if (currentPage > totalPages && totalPages > 0) {
        return totalPages;
    } else if (currentPage === totalPages && totalPages === 0) {
        return 1;
    }
    return currentPage;
};
