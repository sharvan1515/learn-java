export const capitalizeFirstLetter = (string) => {
    if (!string) return string;
    return string.charAt(0).toUpperCase() + string.slice(1);
}

export const validateField = (fieldValue, setErrorFn, errorMessage, type = 'text') => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (fieldValue === '') {
        setErrorFn(errorMessage);
    } else if (type === 'email' && !emailRegex.test(fieldValue)) {
        setErrorFn('Please enter a valid email address');
    } else {
        setErrorFn('');
    }
};

export const handleApiResponse = async (errorResponse, thunkAPI) => {

    if (errorResponse?.response) {
        const { status, data } = errorResponse.response;


        switch (status) {
            case 400:
                if (data?.message) {
                    return thunkAPI.rejectWithValue(data.message || "Invalid request. Please check your inputs.");
                }
                return thunkAPI.rejectWithValue(data || "An unknown error occurred.");
            case 401:
                return thunkAPI.rejectWithValue(data?.message || "Unauthorized access. Please log in again.");
            case 403:
                if (data?.message) {
                    return thunkAPI.rejectWithValue(data.message || "Invalid request. Please check your inputs.");
                }
                return thunkAPI.rejectWithValue(data?.message || "You don't have permission to perform this action.");
            case 404:
                return thunkAPI.rejectWithValue(data?.message || "Requested resource not found.");
            case 500:
                return thunkAPI.rejectWithValue(data?.message || "Something went wrong. Please try again later.");
            default:
                return thunkAPI.rejectWithValue(data?.message || "Operation successful.");
        }
    }

    return thunkAPI.rejectWithValue("An unexpected error occurred.");
};

export const isJsonValid = (jsonString) => {
    try {
        JSON.parse(jsonString);
        return true;
    } catch (e) {
        return false;
    }
}


export const userStatusList = [
    { statusType: 'ACTIVE' },
    { statusType: 'INACTIVE' },
    { statusType: 'SUSPENDED' }
]
