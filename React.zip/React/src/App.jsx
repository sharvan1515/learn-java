import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './layouts/Layout';
import Login from './pages/Login';
import Logout from './components/Logout';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import ProtectedRoute from './components/ProtectedRoute'; // Assuming ProtectedRoute is implemented
import routes from './routes';
import Profile from './pages/Profile';
import ShowUserDetails from './pages/users/ShowUserDetails';
import EditUserDetails from './pages/users/EditUserDetails';

const App = () => {

	return (
		<Router>
			<Routes>
				<Route path="/login" element={<Login />} />
				<Route path="/forgot-password" element={<ForgotPassword />} />
				<Route path="/reset-password" element={<ResetPassword />} />
				<Route path="/logout" element={<Logout />} />
				<Route path="/profile" element={<ProtectedRoute>
					<Layout>
						<Profile />
					</Layout>
				</ProtectedRoute>} />
				<Route path="/showUserDetails/:id" element={<ProtectedRoute>
					<Layout>
						<ShowUserDetails />
					</Layout>
				</ProtectedRoute>} />
				<Route path="/editUserDetails/:id" element={<ProtectedRoute>
					<Layout>
						<EditUserDetails />
					</Layout>
				</ProtectedRoute>} />

				{
					routes.map((route) => (
						<Route
							key={route.path}
							path={route.path}
							element={
								<ProtectedRoute>
									<Layout>
										<route.component />
									</Layout>
								</ProtectedRoute>
							}
						/>
					))
				}
				<Route path="*" element={<Navigate to="/login" />} />
			</Routes>
		</Router>
	);
};

export default App;
