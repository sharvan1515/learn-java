package com.example.EY.dto.user;

import java.time.LocalDateTime;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class UserProfileDTO {

    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String address;
    private String city;
    private String state;
    private String country;
    private String postalCode;
    private LocalDateTime dateOfBirth;
    private String gender;
    private String profilePictureUrl;
    private String bio;
    private String languagePreference;
    private String status;
    private LocalDateTime lastLogin;
    private int loginAttempts;
    private LocalDateTime tokenExpiryDate;
    private boolean isEmailVerified;
    private boolean isPhoneVerified;
    private boolean isTwoFactorEnabled;
    private String preferences;
    private String subscriptionType;
    private LocalDateTime subscriptionExpiry;
    private String referralCode;
    private LocalDateTime lastPasswordChange;
    private boolean emailNotifications;
    private boolean phoneNotifications;
    private boolean termsAccepted;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Set<Long> roleId;
    private Set<String> roles;
}
