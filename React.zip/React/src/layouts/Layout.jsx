import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SideBar from '../components/SideBar';
import Header from '../components/Header';
import { useEffect } from 'react';
import { capitalizeFirstLetter } from '../utils/Handlers';
import { useDispatch, useSelector } from 'react-redux';
import { loggedInUser } from '../features/users/userSlice';

const Layout = ({ children }) => {

    const dispatch = useDispatch();
    const navigate = useNavigate();

    const [activeTab, setActiveTab] = useState('');
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

    const path = window.location.pathname;
    const activeTabName = path.split('/')[1];

    //console.log(activeTabName);



    const handleTabClick = (tab) => {
        setActiveTab(tab);
        if (tab === 'Dashboard') {
            navigate('/');
            return;
        }

        navigate(`/${tab.toLowerCase()}`);
    };

    const toggleSidebar = () => {
        setSidebarOpen(!sidebarOpen);
    };

    const toggleProfileMenu = () => {
        setIsProfileMenuOpen(!isProfileMenuOpen);
    };

    useEffect(() => {
        if (activeTabName === '') {
            setActiveTab('Dashboard');
        } else {
            setActiveTab(capitalizeFirstLetter(activeTabName));
        }
        dispatch(loggedInUser());
    }, [activeTabName]);

    return (
        <div className="flex h-screen">
            <SideBar
                handleTabClick={handleTabClick}
                activeTab={activeTab}
                sidebarOpen={sidebarOpen}
            />
            <div className="flex-1 flex flex-col">
                <Header
                    toggleSidebar={toggleSidebar}
                    toggleProfileMenu={toggleProfileMenu}
                    isProfileMenuOpen={isProfileMenuOpen}
                />
                {React.cloneElement(children, { activeTab })}

            </div>
        </div>
    );
};

export default Layout;
