import { createSlice, createAsyncThunk, current } from '@reduxjs/toolkit';
import { addUser, deleteUser, getUsers, getCurrentLoginUserDetail, changeProfilePicture, updateRoleType, updateUserStatus, updateBasicInfo } from '../../services/userService';
import { handleApiResponse } from '../../utils/Handlers';

export const loggedInUser = createAsyncThunk('users/currentLoginuser', async (_, thunkAPI) => {
    try {
        const response = await getCurrentLoginUserDetail();
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const fetchUserItems = createAsyncThunk('users/fetchUserItems', async (_, thunkAPI) => {

    try {
        const response = await getUsers();
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }

});


export const createUserItem = createAsyncThunk('users/createUserItem', async (item, thunkAPI) => {
    try {
        const response = await addUser(item);
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const updateBasicInfoUser = createAsyncThunk('users/updateBasicInfoUser', async (item, thunkAPI) => {

    try {
        const response = await updateBasicInfo(item);
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const deleteUserData = createAsyncThunk('users/deleteUserData', async (item, thunkAPI) => {

    try {
        const response = await deleteUser(item);
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const updateRole = createAsyncThunk('users/updateRole', async (item, thunkAPI) => {

    try {
        const response = await updateRoleType(item);
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const updateUserStatusType = createAsyncThunk('users/updateUserStatus', async (item, thunkAPI) => {

    try {
        const response = await updateUserStatus(item);
        return response;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const updateProfilePicture = createAsyncThunk('users/updateProfilePicture', async ({ fileData, id }, thunkAPI) => {

    try {
        const data = await changeProfilePicture(fileData, id);
        return data;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }

});

const initialState = {
    users: [],
    currentLoginUser: null,
    loading: false,
    successMessage: '',
    errorMessage: '',
}

const userSlice = createSlice({
    name: 'users',
    initialState,
    extraReducers: (builder) => {
        builder
            // Fetching users
            .addCase(fetchUserItems.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(fetchUserItems.fulfilled, (state, action) => {
                state.loading = false;
                state.users = action.payload;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(fetchUserItems.rejected, (state, action) => {
                state.loading = false;

                console.log(action)

                state.errorMessage = action.payload;
                state.successMessage = '';
            })

            // Creating a new user
            .addCase(createUserItem.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(createUserItem.fulfilled, (state, action) => {
                state.loading = false;
                state.successMessage = 'User Added';
                state.errorMessage = '';
            })
            .addCase(createUserItem.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = action.payload;
                state.successMessage = '';
            })

            .addCase(deleteUserData.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(deleteUserData.fulfilled, (state, action) => {
                state.loading = false;
                state.successMessage = 'User Deleted';
                state.users = state.users.filter(user => user.id !== action.payload);
                state.errorMessage = '';
            })
            .addCase(deleteUserData.rejected, (state, action) => {
                state.loading = false;
                state.successMessage = '';
                state.errorMessage = action.payload;
            })

            .addCase(updateRole.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(updateRole.fulfilled, (state, action) => {
                state.loading = false;
                state.successMessage = 'Role updated successfully!';
                state.errorMessage = '';
            })
            .addCase(updateRole.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = action.payload;
                state.successMessage = '';
            })

            .addCase(updateUserStatusType.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(updateUserStatusType.fulfilled, (state, action) => {
                state.loading = false;
                const index = state.users.findIndex(user => user.id === action.payload.user.id);                
                if (index !== -1) {
                    state.users[index]['status'] = action.payload.user['status'];
                }
                state.successMessage = 'User Status updated successfully!';
                state.errorMessage = '';
            })
            .addCase(updateUserStatusType.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = action.payload;
                state.successMessage = '';
            })

            .addCase(updateBasicInfoUser.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(updateBasicInfoUser.fulfilled, (state, action) => {
                state.loading = false;
                const index = state.users.findIndex(user => user?.id === action.payload?.user?.id);                
                if (index !== -1) {
                    state.users[index] = action.payload.user;
                }
                state.successMessage = 'User Info updated successfully!';
                state.errorMessage = '';
            })
            .addCase(updateBasicInfoUser.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = action.payload;
                state.successMessage = '';
            })

            .addCase(updateProfilePicture.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(updateProfilePicture.fulfilled, (state, action) => {
                state.loading = false;
                const index = state.users.findIndex(user => user?.id === action.payload?.user?.id);                
                if (index !== -1) {
                    state.users[index]['profilePictureUrl'] = action.payload.profile_picture;
                }
                state.successMessage = 'Profile Picture Updated!';
                state.errorMessage = '';
            })
            .addCase(updateProfilePicture.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = action.payload;
                state.successMessage = '';
            })

            // Get Current Login User

            .addCase(loggedInUser.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(loggedInUser.fulfilled, (state, action) => {
                state.loading = false;
                state.currentLoginUser = action.payload;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(loggedInUser.rejected, (state, action) => {
                state.loading = false;
                state.errorMessage = action.payload;
                state.successMessage = '';
            });
    },
});

export const { clearError } = userSlice.actions;
export default userSlice.reducer;
