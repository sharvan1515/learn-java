import React from 'react';
import routes from '../routes';

const SideBar = ({ handleTabClick, activeTab, sidebarOpen }) => {

    return (
        <div
            className={`w-64 bg-gray-800 text-white p-4 transform transition-all ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'
                } md:translate-x-0 fixed md:relative h-full md:block`}
        >
            <div className="text-xl font-bold mb-6">Admin Panel</div>
            <ul>
                {routes.map((tab) => {
                    // Only render protected routes
                    if (tab.protected) {
                        return (
                            <li
                                key={tab.menuName}
                                onClick={() => handleTabClick(tab.menuName)}
                                className={`cursor-pointer p-3 rounded-lg ${activeTab === tab.menuName ? 'bg-blue-600' : 'hover:bg-gray-700'
                                    }`}
                            >
                                {tab.menuName}
                            </li>
                        );
                    }
                    return null; // In case it's not a protected tab, return nothing
                })}
            </ul>
        </div>
    );
};

export default SideBar;
