import React, { useState, useEffect, useMemo } from 'react';
import Modal from '../common/Modal';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRoleItems, createRoleItem, updateRoleItem, deleteRoleItem, clearError } from '../features/roles/roleSlice';
import DialogModal from '../common/DialogModal';
import Toast from '../components/Toast';
import { Pagination } from '../common/Pagination';
import { Button } from '../components/Button';
import BasicSearch from '../common/BasicSearch';
import { updatePageAfterDelete } from '../utils/updatePageAfterDelete';
import { validateField } from '../utils/Handlers';

function Role() {
    const dispatch = useDispatch();

    const { roles, loading, successMessage, errorMessage } = useSelector((state) => state.roles);
    const [showModal, setShowModal] = useState(false);
    const [showModalDialog, setShowModalDialog] = useState(false);
    const [toast, setToast] = useState(null);
    const [currentRole, setCurrentRoleState] = useState(null);
    const [roleName, setRoleName] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [roleNameError, setRoleNameError] = useState('');

    const handleModalOpen = (role = null) => {
        setCurrentRoleState(role);
        setRoleName(role ? role.roleName : '');
        setShowModal(true);
    };

    const handleModalClose = () => {
        setShowModal(false);
        setCurrentRoleState(null);
        setRoleName('');
        setRoleNameError('');
    };

    const handleDeleteModalOpen = (role) => {
        setShowModalDialog(true);
        setCurrentRoleState(role);
    };

    const handleDeleteModalClose = () => {
        setShowModalDialog(false);
        setCurrentRoleState(null);
    };

    const showToast = (message, type = 'success') => {
        setToast({ message, type });
    };

    const closeToast = () => {
        setToast(null);
    };

    const handleSave = async () => {

        validateField(roleName, setRoleNameError, 'Role name cannot be blank');

        if (roleName === '') {
            return;
        }

        const roleData = { roleName: roleName.toUpperCase() };

        try {
            if (currentRole) {
                await dispatch(updateRoleItem({ ...currentRole, ...roleData })).unwrap();
            } else {
                await dispatch(createRoleItem(roleData)).unwrap();
            }
        } catch (error) {
            console.error('Error occurred while saving the role:', error);
        }
        handleModalClose();
    };

    const handleDeleteRole = async () => {
        if (currentRole) {
            try {
                await dispatch(deleteRoleItem(currentRole.id)).unwrap();
                const updatedPage = updatePageAfterDelete(filteredRoles, currentPage, rolesPerPage, currentRole?.id)
                setCurrentPage(updatedPage);
            } catch (error) {
                console.log(error)
            }
            setShowModalDialog(false);
        }
    };

    
    useEffect(() => {
        dispatch(fetchRoleItems());
    }, []);

    useMemo(() => {
        if (errorMessage) {
            showToast(errorMessage, 'error');
        }
        if (successMessage) {
            showToast(successMessage, 'success');
        }
    }, [errorMessage, successMessage]);

    const filteredRoles = useMemo(() => {
        return roles.filter((role) =>
            role.roleName && role.roleName.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [roles, searchQuery]);

    const [currentPage, setCurrentPage] = useState(1);
    const rolesPerPage = 2;
    const indexOfLastRole = currentPage * rolesPerPage;
    const indexOfFirstRole = indexOfLastRole - rolesPerPage;
    const currentRoles = filteredRoles.slice(indexOfFirstRole, indexOfLastRole);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);
    const totalPages = Math.ceil(filteredRoles.length / rolesPerPage);

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h1 className="text-xl font-bold mb-6">Roles</h1>
            <Button
                onClick={() => handleModalOpen()}
                className="mt-4 mb-2 p-1 text-sm bg-blue-500 text-white rounded-lg flex items-center hover:bg-blue-600 focus:outline-none"
            >
                <i className="fas fa-user-plus mr-2"></i> Add New Role
            </Button>

            <BasicSearch onSearch={setSearchQuery} />

            <table className="min-w-full table-auto border-collapse border border-gray-300 text-sm">
                <thead>
                    <tr className="bg-gray-200">
                        <th className="px-4 py-2 border">Role Name</th>
                        <th className="px-4 py-2 border">Description</th>
                        <th className="px-4 py-2 border text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {currentRoles.length === 0 ? (
                        <tr>
                            <td colSpan="7" className="text-center">
                                {loading && <p>Loading...</p>}
                            </td>
                        </tr>
                    ) : (
                        currentRoles.map((role) => (
                            <tr key={role.id} className="border-b">
                                <td className="px-4 py-2">{role?.roleName}</td>
                                <td className="px-4 py-2 text-center">{role?.description ? role?.description : '-'}</td>
                                <td className="px-4 py-2 text-center">
                                    <i
                                        className="fas fa-edit cursor-pointer mr-2"
                                        title="Edit Role"
                                        onClick={() => handleModalOpen(role)}
                                    />
                                    <i
                                        className="fas fa-trash text-red-500 cursor-pointer mr-2"
                                        title="Delete Role"
                                        onClick={() => handleDeleteModalOpen(role)}
                                    />
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>

            <Pagination currentPage={currentPage} totalPages={totalPages} paginate={paginate} />

            {showModal && (
                <Modal currentState={currentRole}>
                    <h2 className="text-xl font-bold mb-4">{currentRole ? 'Edit Role' : 'Add New Role'}</h2>
                    <input
                        type="text"
                        value={roleName}
                        onChange={(e) => setRoleName(e.target.value)}
                        placeholder="Role Name"
                        className="border p-2 mb-4 w-full"
                    />
                    {roleNameError && <span className="text-red-500">{roleNameError}</span>}
                    <div className="flex justify-between">
                        <button
                            onClick={handleModalClose}
                            className="px-4 py-2 bg-gray-400 text-white rounded-md"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleSave}
                            className="px-4 py-2 bg-blue-500 text-white rounded-md"
                        >
                            Save
                        </button>
                    </div>
                </Modal>
            )}

            {showModalDialog && (
                <DialogModal title="Delete Role">
                    <p>Are you sure you want to delete this role?</p>
                    <div className="mt-4 flex justify-end space-x-4">
                        <button
                            onClick={handleDeleteModalClose}
                            className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleDeleteRole}
                            className="px-4 py-2 bg-blue-500 text-white rounded-md"
                        >
                            Confirm
                        </button>
                    </div>
                </DialogModal>
            )}

            {toast && (
                <Toast
                    message={toast.message}
                    type={toast.type}
                    onClose={closeToast}
                />
            )}
        </div>
    );
}

export default Role;
