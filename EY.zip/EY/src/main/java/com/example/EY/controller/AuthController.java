package com.example.EY.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.EY.dto.auth.LoginRequestDTO;
import com.example.EY.dto.auth.RegisterDTO;
import com.example.EY.dto.auth.TokenRefreshRequest;
import com.example.EY.dto.auth.TokenResponse;
import com.example.EY.service.JwtService;
import com.example.EY.service.UserService;

import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@RequestMapping("/api/v1/auth")
@RestController
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @PostMapping("/login")
    public Object login(@Valid @RequestBody LoginRequestDTO loginRequestDTO) {
        Map<String, Object> response = new HashMap<>();
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequestDTO.getEmail(), loginRequestDTO.getPassword()));
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();

            Set<String> userRoles = userDetails.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toSet());
            String loginRequestRole = loginRequestDTO.getRoles();
            if (!userRoles.contains(loginRequestRole)) {
                return new ResponseEntity<>("You do not have access", HttpStatus.FORBIDDEN);
            }

            if (authentication.isAuthenticated()) {
                String accessToken = jwtService.generateAccessToken(loginRequestDTO.getEmail());
                String refreshToken = jwtService.generateRefreshToken(loginRequestDTO.getEmail());
                TokenResponse tokenResponse = new TokenResponse(accessToken, refreshToken);
                return new ResponseEntity<>(tokenResponse, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Invalid user request!", HttpStatus.FORBIDDEN);
            }
        } catch (Exception e) {
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
        }
    }

    @PostMapping("/refresh-token")
    public Object refreshToken(@RequestBody TokenRefreshRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String userName = jwtService.extractUsername(request.getRefreshToken());
            String accessToken = jwtService.generateAccessToken(userName);
            String refreshToken = jwtService.generateRefreshToken(userName);
            TokenResponse tokenResponse = new TokenResponse(accessToken, refreshToken);
            return new ResponseEntity<>(tokenResponse, HttpStatus.OK);
        } catch (Exception e) {
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterDTO registerDTO) {
        try {
            return userService.saveUser(registerDTO);
            // return new ResponseEntity<>(registerDTO, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/forgot-password")
    public String forgotPassword(@RequestBody Map<String, String> requestBody) {
        return userService.processForgotPassword(requestBody.get("email"));
    }

    @GetMapping("/reset-password")
    public String resetPassword(@RequestParam("token") String token) {
        System.out.println("Received token: " + token);
        boolean isValid = userService.validateResetToken(token); // Implement this logic in your service
        if (!isValid) {
            return "Token is Expired";
        }
        return token;
    }

    @PostMapping("/reset-password")
    public String updatePassword(@RequestBody Map<String, String> requestBody) {

        String token = requestBody.get("token");
        String newPassword = resetPassword("newPassword");
        boolean isValid = userService.validateResetToken(token);
        if (!isValid) {
            return "Invalid or expired token.";
        }
        boolean isPasswordUpdated = userService.updatePassword(token, newPassword);

        if (isPasswordUpdated) {
            return "Password has been successfully updated.";
        } else {
            return "Something went wrong while updating the password.";
        }
    }

    @PostMapping("/change-password")
    public Object changePassword(@RequestBody Map<String, String> requestBody) {
        String currentPassword = requestBody.get("current_password");
        String newPassword = requestBody.get("new_password");
        String email = requestBody.get("email");
        return userService.changePassword(email, currentPassword, newPassword);
    }

    @GetMapping("/user-profile")
    public ResponseEntity<?> getUserProfileByToken() {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            return userService.getTheUserDetailsByUsername(username);
        } catch (Exception e) {
            throw new RuntimeException("Failed to get user profile", e);
        }
    }
}
