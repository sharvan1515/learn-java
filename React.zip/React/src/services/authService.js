import apiClient from './api';

export const login = async (loginData) => {
    try {
        const response = await apiClient.post(`/api/v1/auth/login`,loginData);
        return response.data;
    } catch (error) {
        throw error;
    }
};

export const forgotPassword = async (email) => {
    try {
        const response = await apiClient.post(`/api/v1/auth/forgot-password`, email);
        return response;
    } catch (error) {
        throw error;
    }
};

export const resetPassword = async (data) => {
    try {
        const response = await apiClient.post(`/api/v1/reset-password`, data);
        return response;
    } catch (error) {
        throw error;
    }
};

export const changePassword = async (data) => {
    try {
        const response = await apiClient.post(`/api/v1/auth/change-password`, data);
        return response.data;
    } catch (error) {
        throw error;
    }
};
