import React from 'react'
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { useMemo } from 'react';
import { useState } from 'react';


function ShowUserDetails() {

    const navigate = useNavigate(); // To handle redirection

    const { id } = useParams();
    const { users, loading, successMessage, errorMessage } = useSelector((state) => state.users);
    const [user, setUser] = useState([]);
    const [selectedOptions, setSelectedOptions] = useState([]);

    const filterUserById = useMemo(() => {
        return users.find((user) => user.id == id);
    }, [id, users]);

    const handlePrint = () => {
        window.print();
    };

    useEffect(() => {
        setUser(filterUserById);
        if (!filterUserById) {
            navigate("/users");
        }

        if (filterUserById?.preferences) {
            setSelectedOptions(JSON.parse(filterUserById?.preferences));
        }

    }, [filterUserById, navigate]);

    return (
        <div className="p-6 bg-gray-50">

            <div className="flex justify-between items-center p-4">
                <button
                    onClick={() => navigate(-1)}
                    className="px-4 py-2 text-xs bg-gray-300 text-black rounded-md hover:bg-gray-400"
                >
                    <i className="fas fa-arrow-left mr-1"></i>
                    <span>Back</span>
                </button>

                <div className="text-right">
                    <button
                        onClick={handlePrint}
                        className="px-4 py-2 text-xs bg-blue-500 text-white rounded-md hover:bg-blue-600"
                    >
                        <i className="fas fa-print mr-1"></i>
                        <span>Print</span>
                    </button>
                </div>
            </div>

            <div className="border border-gray-300 shadow-md rounded-md bg-white printable">

                <div className="p-4 bg-gray-200 border-b border-gray-300 flex justify-between items-center">
                    <div>
                        <h2 className="text-lg font-semibold text-gray-700">User Details</h2>
                        <p className="text-sm text-gray-500">Full Name: {user.firstName} {user.lastName}  </p>
                    </div>
                    <img
                        src={user?.profilePictureUrl}
                        alt="Profile Picture"
                        className="w-24 h-24 rounded-full object-cover"
                    />
                </div>

                {/* Print Button */}
                <table className="w-full border-collapse">
                    <tbody>
                        {/* First Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">First Name</th>
                            <td className="p-3 text-sm text-gray-800">{user.firstName}</td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Last Name</th>
                            <td className="p-3 text-sm text-gray-800">{user.lastName}</td>
                        </tr>
                        {/* Second Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Email</th>
                            <td className="p-3 text-sm text-gray-800">{user.email}</td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Phone Number</th>
                            <td className="p-3 text-sm text-gray-800">{user.phoneNumber || (<span className="text-red-500">Not Available</span>)}</td>
                        </tr>
                        {/* Third Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Address</th>
                            <td className="p-3 text-sm text-gray-800">{user.address || (<span className="text-red-500">Not Available</span>)}</td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">City</th>
                            <td className="p-3 text-sm text-gray-800">{user.city || (<span className="text-red-500">Not Available</span>)}</td>
                        </tr>
                        {/* Fourth Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">State</th>
                            <td className="p-3 text-sm text-gray-800">{user.state || (<span className="text-red-500">Not Available</span>)}</td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Country</th>
                            <td className="p-3 text-sm text-gray-800">{user.country || (<span className="text-red-500">Not Available</span>)}</td>
                        </tr>
                        {/* Fifth Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Postal Code</th>
                            <td className="p-3 text-sm text-gray-800">{user.postalCode || (<span className="text-red-500">Not Available</span>)}</td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Date of Birth</th>
                            <td className="p-3 text-sm text-gray-800">{user.dateOfBirth || (<span className="text-red-500">Not Available</span>)}</td>
                        </tr>
                        {/* Sixth Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Gender</th>
                            <td className="p-3 text-sm text-gray-800">{user.gender || (<span className="text-red-500">Not Available</span>)}</td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Preference</th>
                            <td className="p-3 text-sm text-gray-800">
                                {
                                    selectedOptions && selectedOptions.length > 0 ? (
                                        selectedOptions.map(option => (
                                            <span key={option.value} className="inline-block bg-blue-500 text-white text-xs font-semibold py-1 px-2 rounded-full mr-2">{option.label}</span>
                                        ))
                                    ) : (
                                        (<span className="text-red-500">Not Available</span>)
                                    )
                                }
                            </td>

                        </tr>
                        {/* Seventh Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Bio</th>
                            <td className="p-3 text-sm text-gray-800">{user.bio || (<span className="text-red-500">Not Available</span>)}</td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Language Preference</th>
                            <td className="p-3 text-sm text-gray-800">{user.languagePreference || (<span className="text-red-500">Not Available</span>)}</td>
                        </tr>
                        {/* Eighth Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Status</th>
                            <td className="p-3 text-sm text-gray-800">
                                {user.status === 'ACTIVE' ? (
                                    <span className="bg-green-400 text-white px-2 py-1 rounded-full">Active</span>
                                ) : user.status === 'INACTIVE' ? (
                                    <span className="bg-yellow-400 text-white px-2 py-1 rounded-full">Inactive</span>
                                ) : user.status === 'SUSPENDED' ? (
                                    <span className="bg-red-400 text-white px-2 py-1 rounded-full">Suspended</span>
                                ) : (
                                    'Unknown Status'
                                )}
                            </td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Last Login</th>
                            <td className="p-3 text-sm text-gray-800">{user.lastLogin || (<span className="text-red-500">Not Available</span>)}</td>
                        </tr>
                        {/* Ninth Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Login Attempts</th>
                            <td className="p-3 text-sm text-gray-800">{user.loginAttempts || (<span className="text-red-500">Not Available</span>)}</td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Is Email Verified</th>
                            <td className="p-3 text-sm text-gray-800">{user.isEmailVerified ? 'Yes' : 'No'}</td>
                        </tr>
                        {/* Tenth Row */}
                        <tr className="border-t border-gray-300">
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Is Phone Verified</th>
                            <td className="p-3 text-sm text-gray-800">{user.isPhoneVerified ? 'Yes' : 'No'}</td>
                            <th className="p-3 text-left bg-gray-100 text-sm font-medium text-gray-600">Is Two Factor Enabled</th>
                            <td className="p-3 text-sm text-gray-800">{user.isTwoFactorEnabled ? 'Yes' : 'No'}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default ShowUserDetails;
