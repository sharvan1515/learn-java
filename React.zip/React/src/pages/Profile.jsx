import React, { useEffect, useMemo, useState } from 'react'
import Modal from '../common/Modal';
import DialogModal from '../common/DialogModal';
import { useDispatch, useSelector } from 'react-redux';
import { loggedInUser, updateProfilePicture } from '../features/users/userSlice';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/Button';
import { changePasswordUser } from '../features/auth/passwordSlice';
import Toast from '../components/Toast';

function Profile() {

    const navigate = useNavigate();
    const dispatch = useDispatch();
    const currentloginUsers = useSelector((state) => state.users.currentLoginUser);
    const { successMessage, errorMessage } = useSelector((state) => state.password);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isModalOpenForProfilePicture, setIsModalOpenForProfilePicture] = useState(false);
    const [uploadStatus, setUploadStatus] = useState(false);
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmNewPassword, setConfirmNewPassword] = useState('');
    const [selectedImage, setSelectedImage] = useState(null);
    const [fileImage, setFileImage] = useState(null);
    const [passwordError, setPasswordError] = useState('');
    const [toast, setToast] = useState(null);

    const openModal = () => setIsModalOpen(true);
    const closeModal = () => {
        setIsModalOpen(false)
        setCurrentPassword('')
        setNewPassword('');
        setConfirmNewPassword('');
    }

    const changeProfilePicture = () => {
        setIsModalOpenForProfilePicture(true);
    }

    const closeModalForProfilePicture = () => {
        setIsModalOpenForProfilePicture(false);
        setSelectedImage(null);
    }

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setFileImage(file);
            setSelectedImage(URL.createObjectURL(file));
        }
    };

    const submitImageChange = () => {
        if (!fileImage) {
            alert('Please select a file to upload!');
            return;
        }
        const file = fileImage;
        setUploadStatus('Uploading...');
        dispatch(updateProfilePicture({ fileData: file, id: currentloginUsers.id }))
            .then((data) => {
                setUploadStatus(false);
                dispatch(loggedInUser());
            })
            .catch((error) => {
                console.error('Error updating profile picture:', error);
            });
        setIsModalOpenForProfilePicture(false);
    }

    const submitChangePassword = async () => {

        if (newPassword !== confirmNewPassword) {
            setPasswordError(`New password and confirmation don't match.`);
            if(passwordError) {
                showToast(passwordError, 'error');
            }
            return;
        }

        if (newPassword.length < 4) {
            setPasswordError(`Password must be at least 4 characters long.`);
            if(passwordError) {
                showToast(passwordError, 'error');
            }
            return;
        }

        try {
            await dispatch(changePasswordUser({
                email: currentloginUsers.email,
                current_password: currentPassword,
                new_password: newPassword,
                new_password_confirmation: confirmNewPassword
            })).unwrap();
            setIsModalOpen(false);
            
            setTimeout(() => {
                navigate('/logout');
                window.location.reload();
            }, 3000);

        } catch (error) {
            console.log(errorMessage);
        }
    }

    const showToast = (message, type = 'success') => {
        setToast({ message, type });
    };

    const closeToast = () => {
        setToast(null);
    };

    
    useMemo(() => {

        if (errorMessage) {
            showToast(errorMessage, 'error');
        }
        if (successMessage) {
            showToast(successMessage, 'success');
        }

        if (passwordError) {
            showToast(passwordError, 'error');
        }

    }, [errorMessage, successMessage, passwordError]);

    return (

        <div className="min-h-screen bg-gray-100 p-6">
            <div className="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow-lg">
                {/* Profile Section */}
                <div className="flex items-center space-x-6 mb-8">
                    <img
                        src={currentloginUsers?.profilePictureUrl ?? 'https://placehold.co/600x400'}
                        alt="Profile Picture"
                        className="w-24 h-24 rounded-full object-cover"
                    />
                    {uploadStatus ? <>{uploadStatus}</> : null}

                    <Button
                        onClick={changeProfilePicture}
                    >Change Profile Picture</Button>
                    <div>
                        {
                            currentloginUsers ? (
                                <>
                                    <h2 className="text-2xl font-semibold text-gray-800">{currentloginUsers.firstName} {currentloginUsers.lastName}</h2>
                                    <p className="text-sm text-gray-500">{currentloginUsers.email}</p>
                                </>

                            ) : (
                                <div>Loading...</div>
                            )
                        }

                    </div>
                </div>

                {/* Account Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-gray-800">Personal Info</h3>
                        <div className="bg-gray-50 p-4 rounded-lg">
                            {
                                currentloginUsers ? (
                                    <>
                                        <p className="text-sm text-gray-600">Name: {currentloginUsers.firstName} {currentloginUsers.lastName}</p>
                                        <p className="text-sm text-gray-600">Email: {currentloginUsers.email}</p>
                                        <p className="text-sm text-gray-600">Phone: {currentloginUsers?.phoneNumber === '' ? '--' : currentloginUsers?.phoneNumber} </p>
                                    </>
                                ) : (
                                    <div>Loading...</div>
                                )
                            }
                        </div>
                    </div>
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-gray-800">Account Settings</h3>
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <button onClick={openModal} className="w-full text-white bg-blue-600 hover:bg-blue-700 p-2 rounded-md">
                                Change Password
                            </button>

                        </div>
                    </div>
                </div>
            </div>
            {
                isModalOpenForProfilePicture && (
                    <Modal>
                        <p>Profile Picture Change</p>
                        <div className="mt-4">
                            <input
                                type="file"
                                accept="image/*"
                                capture="camera"
                                onChange={handleImageChange}
                                className="block mb-4"
                                aria-label="Select Profile Picture"
                            />

                            {/* Image preview */}
                            {selectedImage && (
                                <div className="mb-4">
                                    <img
                                        src={selectedImage}
                                        alt="Profile Preview"
                                        className="w-32 h-32 object-cover rounded-full"
                                    />
                                </div>
                            )}
                        </div>
                        <div className="mt-4 flex justify-end space-x-4">
                            <button
                                onClick={closeModalForProfilePicture}
                                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={submitImageChange}
                                className="px-4 py-2 bg-blue-500 text-white rounded-md"
                            >
                                Confirm
                            </button>
                        </div>
                    </Modal>
                )
            }

            {
                isModalOpen && (
                    <Modal title="Confirmation">
                        <h2 className="text-xl font-bold mb-4">Change Password</h2>
                        <input
                            type="password"
                            value={currentPassword}
                            onChange={(e) => setCurrentPassword(e.target.value)}
                            placeholder="Current Password"
                            className="border p-2 mb-4 w-full"
                        />
                        <input
                            type="password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="New Password"
                            className="border p-2 mb-4 w-full"
                        />

                        <input
                            type="password"
                            value={confirmNewPassword}
                            onChange={(e) => setConfirmNewPassword(e.target.value)}
                            placeholder="Confirm New Password"
                            className="border p-2 mb-4 w-full"
                        />
                        <div className="mt-4 flex justify-end space-x-4">
                            <button
                                onClick={closeModal}
                                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={submitChangePassword}
                                className="px-4 py-2 bg-blue-500 text-white rounded-md"
                            >
                                Confirm
                            </button>
                        </div>
                    </Modal>
                )
            }
            {toast && (
                <Toast
                    message={toast.message}
                    type={toast.type}
                    onClose={closeToast}
                />
            )}
        </div>
    )
}

export default Profile