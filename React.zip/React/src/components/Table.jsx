export const Table = ({ columns, data, handleEdit, handleDelete }) => {

    console.log('Table:', data);

    return (
        <table className="min-w-full table-auto border-collapse border border-gray-300">
            <thead>
                <tr className="bg-gray-200">
                    {columns.map((column, index) => (
                        <th key={index} className="px-4 py-2 border">{column}</th>
                    ))}
                    <th className="px-4 py-2 border text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                {data.map((item, index) => (
                    <tr className="border-b" key={index}>
                        {columns.map((column, index) => (
                            <td key={index} className="px-4 py-2">{item[column]}</td>
                        ))}
                        <td className="px-4 py-2 text-center">
                            <button
                                onClick={() => handleEdit(item)}
                                className="px-4 py-2 bg-blue-500 text-white rounded-md mr-2"
                            >
                                Edit
                            </button>
                            <button
                                onClick={() => handleDelete(item)}
                                className="px-4 py-2 bg-red-500 text-white rounded-md"
                            >
                                Delete
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
}