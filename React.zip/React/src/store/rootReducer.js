import { combineReducers } from 'redux';
import roleReducer from "../features/roles/roleSlice";
import userReducer from "../features/users/userSlice";
import authReducer from "../features/auth/authSlice";
import uiReducer from "../features/ui/uiSlice";
import passwordReducer from "../features/auth/passwordSlice";

const rootReducer = combineReducers({
    roles: roleReducer,
    users: userReducer,
    auth: authReducer,
    password: passwordReducer,
    ui: uiReducer
})

export default rootReducer;