import { lazy } from 'react';
const Role = lazy(() => import('./pages/Role'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Users = lazy(() => import('./pages/users/Users'));
const Settings = lazy(() => import('./pages/Settings'));
const Login = lazy(() => import('./pages/Login'));

const routes = [
    {
        path: '/',
        exact: true,
        component: Dashboard,
        menuName: 'Dashboard',
        protected: true,
    },
    {
        path: '/users',
        exact: true,
        component: Users,
        menuName: 'Users',
        protected: true,
    },
    {
        path: '/roles',
        exact: true,
        component: Role,
        menuName: 'Roles',
        protected: true,
    },
    // {
    //     path: '/settings',
    //     exact: true,
    //     component: Settings,
    //     menuName: 'Settings',
    //     protected: true,
    // },
    {
        path: '/login',
        exact: true,
        component: Login,
        menuName: 'Login',
        protected: false,
    },
];

export default routes;
