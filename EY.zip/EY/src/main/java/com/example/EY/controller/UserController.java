package com.example.EY.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.EY.dto.user.AddUserFromBackendDTO;
import com.example.EY.dto.user.EditUserDTO;
import com.example.EY.dto.user.UserResponseDTO;
import com.example.EY.model.Role;
import com.example.EY.model.User;
import com.example.EY.repository.RoleRepository;
import com.example.EY.repository.UserRepository;
import com.example.EY.service.FileUploadService;
import com.example.EY.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private FileUploadService fileUploadService;

    @Autowired
    private UserService userService;

    @GetMapping
    public ResponseEntity<List<UserResponseDTO>> getAllUsers() {
        List<User> users = userRepository.findAll();

        List<UserResponseDTO> userResponseDTOs = users.stream()
                .map(user -> {
                    Set<String> roleNames = user.getRoles().stream()
                            .map(role -> role.getRoleName())
                            .collect(Collectors.toSet());

                    Set<Long> roleId = user.getRoles().stream().map(role -> role.getId()).collect(Collectors.toSet());

                    return new UserResponseDTO(
                            user.getId(),
                            user.getFirstName(),
                            user.getLastName(),
                            user.getEmail(),
                            user.getPhoneNumber(),
                            user.getAddress(),
                            user.getCity(),
                            user.getState(),
                            user.getCountry(),
                            user.getPostalCode(),
                            user.getDateOfBirth(),
                            user.getGender() == null ? "" : user.getGender().name(),
                            user.getProfilePictureUrl(),
                            user.getBio(),
                            user.getLanguagePreference(),
                            user.getStatus().name(), // Convert Status enum to String
                            user.getLastLogin(),
                            user.getLoginAttempts(),
                            user.getTokenExpiryDate(),
                            user.isEmailVerified(),
                            user.isPhoneVerified(),
                            user.isTwoFactorEnabled(),
                            user.getPreferences(),
                            user.getSubscriptionType().name(), // Convert SubscriptionType enum to String
                            user.getSubscriptionExpiry(),
                            user.getReferralCode(),
                            user.getLastPasswordChange(),
                            user.isEmailNotifications(),
                            user.isPhoneNotifications(),
                            user.isTermsAccepted(),
                            user.getCreatedAt(),
                            user.getUpdatedAt(),
                            roleId,
                            roleNames // Assign the roles
                    );
                })
                .collect(Collectors.toList());
        return new ResponseEntity<>(userResponseDTOs, HttpStatus.OK);
    }

    @PostMapping("/addUserBybackend")
    public ResponseEntity<?> registerUserByBackend(@Valid @RequestBody AddUserFromBackendDTO addUserFromBackendDTO) {

        try {
            return userService.saveUserByBackend(addUserFromBackendDTO);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/pofilePicUpdate/{userId}")
    public ResponseEntity<?> pofilePicUpdate(@PathVariable Long userId, @RequestParam("file") MultipartFile file) {

        Map<String, Object> response = new HashMap<>();

        try {
            Optional<User> user = userRepository.findById(userId);
            if (!user.isPresent()) {

                return new ResponseEntity<>("User Not Found", HttpStatus.NOT_FOUND);
            }
            User exitUser = user.get();
            String filePath = fileUploadService.uploadFile(file);
            exitUser.setProfilePictureUrl(filePath);
            userRepository.save(exitUser);
            response.put("message", "Profile Picture Updated");
            response.put("user", user);
            response.put("profile_picture", filePath);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{userId}/status/{statusValue}")
    public ResponseEntity<?> changeStatus(@PathVariable Long userId, @PathVariable String statusValue) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<User> userOptional = userRepository.findById(userId);
            if (userOptional.isPresent()) {
                User user = userOptional.get();
                try {
                    User.Status status = User.Status.valueOf(statusValue.toUpperCase());
                    user.setStatus(status);
                    userRepository.save(user);
                    response.put("message", "User status updated successfully.");
                    response.put("user", user);
                    return new ResponseEntity<>(response, HttpStatus.OK);
                } catch (IllegalArgumentException e) {
                    return new ResponseEntity<>("Invalid status value provided.", HttpStatus.BAD_REQUEST);
                }
            } else {
                return new ResponseEntity<>("User not found.", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{userId}/role/{roleId}")
    public ResponseEntity<?> changeRole(@PathVariable Long userId, @PathVariable Long roleId) {
        try {
            Optional<User> userOptional = userRepository.findById(userId);
            if (!userOptional.isPresent()) {
                return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
            }
            User user = userOptional.get();
            Optional<Role> roleOptional = roleRepository.findById(roleId);
            if (!roleOptional.isPresent()) {
                return new ResponseEntity<>("Role not found", HttpStatus.NOT_FOUND);
            }
            Role role = roleOptional.get();
            Set<Role> roles = user.getRoles();
            roles.clear();
            roles.add(role);
            userRepository.save(user);
            return new ResponseEntity<>("User's role updated successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<?> deleteUser(@PathVariable Long userId) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<User> user = userRepository.findById(userId);
            if (!user.isPresent()) {
                return new ResponseEntity<>("User Not Found", HttpStatus.NOT_FOUND);
            }
            User exitUser = user.get();
            exitUser.getRoles().clear();
            userRepository.save(exitUser);
            userRepository.delete(exitUser);
            response.put("message", "User Deleted");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/updateProfile/{userId}")
    public ResponseEntity<?> updateProfile(@PathVariable Long userId, @Valid @RequestBody EditUserDTO editUserDTO) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<User> user = userRepository.findById(userId);
            if (!user.isPresent()) {
                return new ResponseEntity<>("User Not Found", HttpStatus.NOT_FOUND);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            String preferencesJson = objectMapper.writeValueAsString(editUserDTO.getPreferences());
            User exitUser = user.get();
            exitUser.setFirstName(editUserDTO.getFirstName());
            exitUser.setLastName(editUserDTO.getLastName());
            exitUser.setEmail(editUserDTO.getEmail());
            exitUser.setPhoneNumber(editUserDTO.getPhoneNumber());
            exitUser.setCountry(editUserDTO.getCountry());
            exitUser.setCity(editUserDTO.getCity());
            exitUser.setState(editUserDTO.getState());
            exitUser.setAddress(editUserDTO.getAddress());
            exitUser.setPostalCode(editUserDTO.getPostalCode());
            exitUser.setBio(editUserDTO.getBio());
            exitUser.setLanguagePreference(editUserDTO.getLanguagePreference());
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            exitUser.setDateOfBirth(LocalDate.parse(editUserDTO.getDateOfBirth(), formatter).atStartOfDay());
            exitUser.setGender(User.Gender.valueOf(editUserDTO.getGender().toUpperCase()));
            exitUser.setPreferences(preferencesJson);
            userRepository.save(exitUser);
            response.put("message", "User Details Updated");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
