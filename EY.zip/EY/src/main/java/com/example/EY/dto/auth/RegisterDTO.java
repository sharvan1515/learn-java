package com.example.EY.dto.auth;

import java.util.Set;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RegisterDTO {

    @NotBlank(message = "firstName is mandatory")
    @Size(min = 3, max = 50, message = "firstName must be between 3 and 50 characters")
    private String firstName;

    @NotBlank(message = "lastName is mandatory")
    @Size(min = 3, max = 50, message = "lastName must be between 3 and 50 characters")
    private String lastName;

    @NotBlank(message = "password is mandatory")
    @Size(min = 3, max = 50, message = "password must be between 3 and 50 characters")
    private String password;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should be valid")
    private String email;

    
    private Set<String> roles;
    

}
