import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const ProtectedRoute = ({ children }) => {
	const token = localStorage.getItem('accessToken');
	// const role = localStorage.getItem('role');
	const navigate = useNavigate();
	const [isLoading, setIsLoading] = useState(true);

	useEffect(() => {
		//if (!token || (role !== 'ADMIN' && role !== 'MANAGER' && role !== 'SCHOOL')) {
		if (!token) {
			navigate('/login');
		} else {
			setIsLoading(false);
		}
	}, [token, navigate]);

	if (isLoading) {
		return <div>Loading...</div>;
	}

	return children;
};

export default ProtectedRoute;
