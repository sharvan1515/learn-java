import React, { useState, useEffect } from 'react';

const Toast = ({ message, type, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose();
        }, 3000);
        return () => clearTimeout(timer);
    }, [onClose]);

    const toastStyles = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        info: 'bg-blue-500',
    };

    return (
        <div
            className={`fixed top-4 right-4 w-80 p-4 rounded-lg shadow-lg text-white ${toastStyles[type]} transition-all duration-300 ease-in-out`}
            role="alert"
        >
            <div className="flex justify-between items-center">
                {message && (
                    typeof message === 'object' ? (
                        Object.entries(message).map(([field, messages]) => (
                            <div key={field} className="text-center mb-4">
                                    <p key={field}>{messages}</p>
                            </div>
                        ))
                    ) : (
                        <div>{message}</div>
                    )
                )}
                <button
                    onClick={onClose}
                    className="text-white ml-4 focus:outline-none"
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M6 18L18 6M6 6l12 12"
                        />
                    </svg>
                </button>
            </div>
        </div>
    );
};

export default Toast;
