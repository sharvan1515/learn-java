import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { doForgotPassword } from "../features/auth/authSlice";
import { useDispatch, useSelector } from 'react-redux';

const ForgotPassword = () => {

    const { loading, successMessage, errorMessage } = useSelector((state) => state.auth);

    const [email, setEmail] = useState('');

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await dispatch(doForgotPassword(
                {
                    email: email
                }
            )).unwrap();

            setTimeout(() => {
                navigate('/login');
                window.location.reload();
            }, 3000)
            
            resetForm();
        } catch (error) {
            resetForm();
        }
    };

    const resetForm = () => {
        setEmail('');
    };

    useEffect(() => {
        const token = localStorage.getItem('accessToken');
        if (token) {
            navigate('/');
        }
    }, [navigate]);

    console.log(errorMessage);

    return (
        <div className="flex justify-center items-center h-screen bg-gray-200">
            <div className="bg-white p-8 rounded-lg shadow-md w-96">
                <h2 className="text-2xl font-semibold text-center mb-6">Forgot Password</h2>

                {/* Display error or success message */}
                {errorMessage && <p className="text-red-500 text-center mb-4">{errorMessage}</p>}
                {successMessage && <p className="text-green-500 text-center mb-4">{successMessage}</p>}

                <form onSubmit={handleSubmit}>
                    {/* Email field */}
                    <div className="mb-4">
                        <label htmlFor="email" className="block text-gray-700">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg mt-2"
                            required
                        />
                    </div>

                    {/* Submit button */}
                    <button
                        type="submit"
                        className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"

                        disabled={loading}  // Disable the button when loading
                    >
                        {loading ? 'Sending...' : 'Send Reset Link'}
                    </button>
                </form>

                <div className="mt-4 text-center">
                    <p>
                        <a href="/login" className="text-blue-600 hover:underline">
                            Login
                        </a>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default ForgotPassword;
