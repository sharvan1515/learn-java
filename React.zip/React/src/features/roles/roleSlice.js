import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { fetchRoles, createRole, updateRole, deleteRole } from '../../services/roleService';
import { handleApiResponse } from '../../utils/Handlers';

export const fetchRoleItems = createAsyncThunk('roles/fetchRoleItems', async (_, thunkAPI) => {
    try {
        const data = await fetchRoles();
        return data;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const createRoleItem = createAsyncThunk('roles/createRoleItem', async (item, thunkAPI) => {
    try {
        const data = await createRole(item);
        return data;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const updateRoleItem = createAsyncThunk('roles/updateRoleItem', async (item, thunkAPI) => {
    try {
        const data = await updateRole(item);
        return data;
    } catch (error) {
        return handleApiResponse(error, thunkAPI);
    }
});

export const deleteRoleItem = createAsyncThunk('roles/deleteRoleItem', async (id, thunkAPI) => {
    try {
        const data = await deleteRole(id);
        return data;
    } catch (error) {

        return handleApiResponse(error, thunkAPI);
    }
});

const initialState = {
    roles: [],
    loading: false,
    successMessage: '',
    errorMessage: '',
};

const roleSlice = createSlice({
    name: 'roles',
    initialState,
    reducers: {
        clearError: (state) => {
            //state.error = null;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchRoleItems.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(fetchRoleItems.fulfilled, (state, action) => {
                state.loading = false;
                state.roles = action.payload;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(fetchRoleItems.rejected, (state, action) => {
                state.loading = false;
                state.successMessage = '';
                state.errorMessage = action.payload;
            })

            .addCase(createRoleItem.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(createRoleItem.fulfilled, (state, action) => {
                state.loading = false;
                state.roles.push(action.payload.role)
                state.successMessage = 'Role Added';
                state.errorMessage = '';
            })
            .addCase(createRoleItem.rejected, (state, action) => {
                state.loading = false;
                state.successMessage = '';
                state.errorMessage = action.payload;
            })

            .addCase(updateRoleItem.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(updateRoleItem.fulfilled, (state, action) => {
                state.loading = false;
                state.successMessage = 'Role Updated';
                const index = state.roles.findIndex(role => role.id === action.payload.role.id);                
                if (index !== -1) {
                    state.roles[index] = action.payload.role;
                }
                state.errorMessage = '';
            })
            .addCase(updateRoleItem.rejected, (state, action) => {
                state.loading = false;
                state.successMessage = '';
                state.errorMessage = action.payload;
            })

            .addCase(deleteRoleItem.pending, (state) => {
                state.loading = true;
                state.successMessage = '';
                state.errorMessage = '';
            })
            .addCase(deleteRoleItem.fulfilled, (state, action) => {
                state.loading = false;
                state.successMessage = 'Role Deleted';
                state.roles = state.roles.filter(role => role.id !== action.payload);
                state.errorMessage = '';
            })
            .addCase(deleteRoleItem.rejected, (state, action) => {
                state.loading = false;
                state.successMessage = '';
                state.errorMessage = action.payload;
            });
    },
});

export const { clearError } = roleSlice.actions;
export default roleSlice.reducer;
