import React from 'react'

function Modal({children, currentState}) {
    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
            <div className="bg-white p-6 rounded-md w-1/3">
                {children}
            </div>
        </div>
    )
}

export default Modal