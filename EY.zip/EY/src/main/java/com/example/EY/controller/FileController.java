package com.example.EY.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.EY.service.FileUploadService;

import org.springframework.core.io.Resource;

@RequestMapping("/uploads")
@RestController
public class FileController {

    @Autowired
    private FileUploadService fileUploadService;

    @GetMapping("/photo/{fileName}")
    public ResponseEntity<Resource> getFile(@PathVariable String fileName) {
        try {
            return fileUploadService.showImage(fileName);
        } catch (Exception e) {
            throw new RuntimeException("File not found" + fileName);
        }
    }
}
