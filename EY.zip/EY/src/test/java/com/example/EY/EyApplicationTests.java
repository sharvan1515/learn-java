package com.example.EY;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EyApplicationTests {

	@Test
	void contextLoads() {
	}

}
