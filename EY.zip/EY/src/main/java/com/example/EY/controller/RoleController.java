package com.example.EY.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.EY.dto.role.RoleRequestDTO;
import com.example.EY.model.Role;
import com.example.EY.repository.RoleRepository;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PutMapping;

@RequestMapping("/api/v1/roles")
@RestController
public class RoleController {

    @Autowired
    private RoleRepository roleRepository;

    @GetMapping
    public ResponseEntity<?> getAllRoles() {
        try {
            List<Role> roles = roleRepository.findAll();
            return new ResponseEntity<>(roles, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Something went Wrong", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping
    public ResponseEntity<?> addnewRole(@Valid @RequestBody RoleRequestDTO roleRequestDTO) {

        Map<String, Object> response = new HashMap<>();
        try {
            if (roleRepository.findByRoleName(roleRequestDTO.getRoleName()) != null) {
                response.put("message", "Role name must be unique");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }

            Role role = new Role();
            role.setRoleName(roleRequestDTO.getRoleName());
            role.setDescription(roleRequestDTO.getDescription());

            roleRepository.save(role);
            response.put("message", "Role Created");
            response.put("role", role);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{roleId}")
    public ResponseEntity<?> getRoleById(@PathVariable Long roleId) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<Role> role = roleRepository.findById(roleId);
            if (role.isPresent()) {
                return new ResponseEntity<>(role.get(), HttpStatus.OK);
            } else {
                response.put("message", "Role Not Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{roleId}")
    @Transactional
    public ResponseEntity<?> updateRole(@PathVariable Long roleId, @Valid @RequestBody RoleRequestDTO roleBody) {
        Map<String, Object> response = new HashMap<>();
        try {
            Role role = roleRepository.findById(roleId).orElseThrow(
                    () -> new RuntimeException("Role not found"));

            Role roleByName = roleRepository.findByRoleName(roleBody.getRoleName());
            if (roleByName != null && !roleByName.getId().equals(roleId)) {
                response.put("message", "Role name must be unique");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            
            role.setRoleName(roleBody.getRoleName());
            role.setDescription(roleBody.getDescription());
            roleRepository.save(role);
            response.put("message", "Role Updated");
            response.put("role", role);
            return new ResponseEntity<>(response, HttpStatus.ACCEPTED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{roleId}")
    public ResponseEntity<?> deleteRole(@PathVariable Long roleId) {
        Map<String, Object> response = new HashMap<>();
        try {
            Optional<Role> checkRole = roleRepository.findById(roleId);
            if (checkRole.isPresent()) {
                roleRepository.delete(checkRole.get());
                response.put("message", "Role Deleted");
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                response.put("message", "Role Not Found");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
