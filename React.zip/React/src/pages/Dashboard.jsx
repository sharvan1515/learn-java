import React, { useState, useEffect } from 'react';
import { fetchUserItems } from '../features/users/userSlice';
import { fetchRoleItems } from '../features/roles/roleSlice';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

function Dashboard() {

    const dispatch = useDispatch();

    const users = useSelector((state) => state.users.users);
    const roles = useSelector((state) => state.roles.roles);

    const [newUsers, setNewUsers] = useState(0);
    const [newRoles, setNewRoles] = useState(10);

    useEffect(() => {
        dispatch(fetchUserItems());
        dispatch(fetchRoleItems());
    }, [dispatch]);

    useEffect(() => {
        setNewUsers(users?.length || 0);
        setNewRoles(roles?.length || 0);
    }, [users, roles]);

    return (
        <div className="p-6 bg-gray-50">
            <h1 className="text-2xl font-semibold text-gray-800 mb-6">Dashboard</h1>

            {/* Card Grid Layout */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">

                {/* Card 1 - Live New Orders Count */}
                <div className="bg-white shadow-lg rounded-lg p-6">
                    <h2 className="text-xl font-semibold text-gray-700">Total Users</h2>
                    <div className="mt-4 text-center">
                        <span className="text-3xl font-bold text-blue-500">
                            <Link to="users">{newUsers}</Link>
                        </span>
                    </div>
                </div>

                {/* Card 2 - Live Active Users Count */}
                <div className="bg-white shadow-lg rounded-lg p-6">
                    <h2 className="text-xl font-semibold text-gray-700">Total Roles</h2>
                    <div className="mt-4 text-center">
                        <span className="text-3xl font-bold text-green-500">
                            <Link to="roles">{newRoles}</Link>
                        </span>
                    </div>
                </div>

            </div>
        </div>
    );
}

export default Dashboard;
