package com.example.EY.dto.role;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RoleRequestDTO {
    
    @NotBlank(message = "roleName is mandatory")
    @Size(min = 3, max = 50, message = "roleName must be between 3 and 50 characters")
    private String roleName;

    @Column(name = "description", length = 100)
    private String description;

}
