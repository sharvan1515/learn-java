import apiClientJava from "./api"

export const fetchRoles = async () => {
    try {
        const response = await apiClientJava.get('/api/v1/roles');
        return response.data;
    } catch (error) {
        throw error;
    }
};

export const createRole = async (role) => {
    try {
        const response = await apiClientJava.post('/api/v1/roles', role);
        return response.data;
    } catch (error) {
        throw error;
    }
};

export const updateRole = async (role) => {
    try {
        const response = await apiClientJava.put(`/api/v1/roles/${role.id}`, role);
        return response.data;
    } catch (error) {
        throw error;
    }
};

export const deleteRole = async (id) => {
    try {
        await apiClientJava.delete(`/api/v1/roles/${id}`);
        return id;
    } catch (error) {
        throw error;
    }
};
