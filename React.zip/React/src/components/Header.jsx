import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

function Header({ toggleSidebar, toggleProfileMenu, isProfileMenuOpen }) {

    const [userFullName, setUserFullName] = useState('');
    const [userRole, setUserRole] = useState('');
    const [userStatus, setUserStatus] = useState('');
    const [userProfilePic, setUserProfilePic] = useState('');

    const currentUser = useSelector((state) => state.users?.currentLoginUser);

    useEffect(() => {

        if (currentUser?.firstName && currentUser?.lastName) setUserFullName(currentUser?.firstName + ' ' + currentUser?.lastName);
        if (currentUser?.roles) setUserRole(currentUser?.roles);
        if (currentUser?.profilePictureUrl) setUserProfilePic(currentUser?.profilePictureUrl);

        if(currentUser?.status) setUserStatus(currentUser?.status);

    }, [currentUser]);


    const handleLogout = () => {
        window.location.href = '/logout';
    };
    return (
        <header className="flex justify-between items-center bg-white p-4 shadow-md md:shadow-none">
            <div className="text-xl font-semibold">Welcome to the Admin Dashboard</div>

            {/* Hamburger Menu for Small Screens */}
            <button
                onClick={toggleSidebar}
                className="md:hidden p-2 rounded-md hover:bg-gray-100 focus:outline-none"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>

            {/* User Profile Section */}
            <div className="flex items-center space-x-4">
                <div className="relative">
                    <button
                        onClick={toggleProfileMenu}
                        className="flex items-center space-x-2 p-2 rounded-full hover:bg-gray-100"
                    >
                        <span className="font-medium">{userFullName} ({userRole})</span>
                        <img className="w-8 h-8 rounded-full" 
                            src={userProfilePic ?? 'https://placehold.co/600x400'}
                            alt="Profile" />
                    </button>
                    {/* Profile Dropdown */}
                    {isProfileMenuOpen && (
                        <div className="absolute right-0 mt-2 bg-white shadow-lg rounded-lg w-48">
                            <ul className="py-2">
                                <Link to="/profile"><li className="px-4 py-2 hover:bg-gray-200 cursor-pointer" onClick={toggleProfileMenu}>Profile</li></Link>
                                <li
                                    className="px-4 py-2 hover:bg-gray-200 cursor-pointer"
                                    onClick={handleLogout}
                                >Logout</li>
                            </ul>
                        </div>
                    )}
                </div>
            </div>
        </header>
    )
}

export default Header