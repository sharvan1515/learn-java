import axios from 'axios';
import { jwtDecode } from "jwt-decode";

const API_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8082/';

const apiClient = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

const checkTokenExpiry = (token) => {
    if (!token) return true;
    const { exp } = jwtDecode(token);
    return Date.now() >= exp * 1000;
};

const refreshToken = async () => {
    try {
        const response = await axios.post(`${API_URL}api/v1/auth/refresh-token`, {
            refreshToken: localStorage.getItem('refreshToken'),
        });
        localStorage.setItem('accessToken', response.data.accessToken);
        return response.data.accessToken;
    } catch (error) {
        console.error('Failed to refresh token', error);
        return null;
    }
};

apiClient.interceptors.request.use(
    async (config) => {
        let token = localStorage.getItem('accessToken');
        if(token) {
            if(checkTokenExpiry(token)) {
                token = await refreshToken();
                if (!token) {
                    localStorage.removeItem('accessToken');
                    localStorage.removeItem('refreshToken');
                    window.location.href = '/login';
                    return Promise.reject(new Error('Token expired'));
                }
            }
            config.headers['Authorization'] = `Bearer ${token}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

apiClient.postFile = async (url, formData) => {
    try {
        const response = await apiClient.post(url, formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
        return response;
    } catch (error) {
        throw error;
    }
};

export default apiClient;
