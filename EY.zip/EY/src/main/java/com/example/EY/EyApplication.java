package com.example.EY;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.logging.LogLevel;
import org.springframework.boot.logging.LoggingSystem;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class EyApplication {

	public static void main(String[] args) {
		SpringApplication.run(EyApplication.class, args);
		LoggingSystem.get(ClassLoader.getSystemClassLoader()).setLogLevel("org.springframework", LogLevel.DEBUG);
	}
}
