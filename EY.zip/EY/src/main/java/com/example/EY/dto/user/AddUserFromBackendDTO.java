package com.example.EY.dto.user;

import java.util.Set;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AddUserFromBackendDTO {

    @NotBlank(message = "firstName is mandatory")
    @Size(min = 3, max = 50, message = "firstName must be between 3 and 50 characters")
    private String firstName;

    @NotBlank(message = "lastName is mandatory")
    @Size(min = 3, max = 50, message = "lastName must be between 3 and 50 characters")
    private String lastName;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should be valid")
    private String email;
    
    @NotEmpty(message = "Roles is mandatory")
    private Set<String> roles;
    

}
