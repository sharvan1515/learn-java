import apiClient from './api';

export const getUsers = async () => {
    try {
        const response = await apiClient.get('/api/v1/users');
        return response.data;
    } catch (error) {
        throw error;
    }
};

export const addUser = async (userData) => {
    try {
        const response = await apiClient.post('/api/v1/users/addUserBybackend', userData);
        return response.data;
    } catch (error) {
        throw error;
    }
};

export const getCurrentLoginUserDetail = async () => {

    try {
        const response = await apiClient.get(`/api/v1/auth/user-profile`);
        return response.data;
    } catch (error) {
        throw error;
    }

}

export const updateBasicInfo = async (user) => {
    try {
        const response = await apiClient.put(`/api/v1/users/updateProfile/${user.id}`, user);
        return response.data;
    } catch (error) {
        throw error;
    }

}

export const updateRoleType = async (user) => {
    try {
        const response = await apiClient.put(`/api/v1/users/${user.id}/role/${user.role}`);
        return response.data;
    } catch (error) {
        throw error;
    }

}

export const updateUserStatus = async (user) => {
    try {
        const response = await apiClient.put(`/api/v1/users/${user.id}/status/${user.status}`);
        return response.data;
    } catch (error) {
        throw error;
    }

}

export const deleteUser = async (userId) => {
    try {
        await apiClient.delete(`/api/v1/users/${userId}`);
        return userId;
    } catch (error) {
        throw error;
    }

}


export const changeProfilePicture = async (file, id) => {
    try {
        const formData = new FormData();
        formData.append('file', file);
        const response = await apiClient.postFile(`/api/v1/users/pofilePicUpdate/${id}`, formData);
        return response.data;
    } catch (error) {
        throw error;
    }

}
