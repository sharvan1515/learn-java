import React from 'react'

function Settings({activeTab}) {

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h3 className="text-xl font-semibold mb-4">{activeTab}</h3>
            <p>Change application settings and preferences here.</p>
        </div>
    )
}

export default Settings